# MINOZA BLOCKS 0.4.0

A redesigned native Android jewel-block puzzle built around the supplied visual reference: royal-blue gradient surfaces, a dark 8×8 board, beveled glossy gems, a crown/best-score header, and custom game screens.

## Included
- Home screen with MINOZA identity, best score, and play/settings navigation.
- 8×8 puzzle board, three-piece tray, fixed-orientation pieces, drag-and-drop, and lifted translucent placement preview.
- Simultaneous row/column clearing; intersections are counted once; 10 points per cleared cell.
- No gravity, no timer, no rotation or flipping, and no levels.
- Combo display, best-score persistence, pause/resume, restart, settings, and game-over screens.
- Procedurally synthesized sound effects for tap, pickup, placement, invalid placement, clear, combo, game over, navigation, and a new record. Sound and vibration can be toggled.
- Canvas-drawn beveled gem cubes, highlights, shadows, clear flashes, particles, and screen transitions.

## Build
The included GitHub Actions workflow expects this archive at the repository root as `Minoza-Blocks-Android-v0.4.0.zip`. It runs the local JVM unit tests and builds `:app:assembleDebug` using Java 17, Android SDK 36, and Gradle 8.13.

## Verification notes
The game engine was exercised with standalone Java tests for placement, bounds, simultaneous row/column clearing, unique intersection counting, score calculation, no gravity, combo reset, and restart. Android source syntax was checked against lightweight local API stubs, and the XML resources were parsed successfully. A real Android Gradle build and installation on a physical phone have not yet been verified in this environment.
