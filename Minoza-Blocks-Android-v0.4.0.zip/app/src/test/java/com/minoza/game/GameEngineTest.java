package com.minoza.game;

import org.junit.Test;
import java.lang.reflect.Field;
import static org.junit.Assert.*;

public class GameEngineTest {
    @Test public void startsWithThreeFixedPieces() {
        GameEngine game = new GameEngine(7L, 0);
        for (int i = 0; i < 3; i++) {
            assertNotNull(game.getPiece(i));
            assertFalse(game.isUsed(i));
        }
    }

    @Test public void rejectsOutOfBoundsPlacementWithoutChangingBoard() {
        GameEngine game = new GameEngine(9L, 0);
        GameEngine.Piece p = game.getPiece(0);
        assertFalse(game.canPlace(p, 8, 0));
        assertFalse(game.place(0, 8, 0));
        for (int[] row : game.copyBoard()) for (int cell : row) assertEquals(0, cell);
        assertEquals(0, game.getMoves());
    }

    @Test public void acceptedPlacementUsesExactlyThePieceCellCount() {
        GameEngine game = new GameEngine(12L, 0);
        GameEngine.Piece p = game.getPiece(0);
        assertTrue(game.place(0, 0, 0));
        int filled = 0;
        for (int[] row : game.copyBoard()) for (int cell : row) if (cell != 0) filled++;
        assertEquals(p.size(), filled);
        assertTrue(game.isUsed(0));
    }

    @Test public void simultaneousRowAndColumnClearingCountsIntersectionOnce() throws Exception {
        GameEngine game = null;
        int singleSlot = -1;
        for (long seed = 0; seed < 500 && singleSlot < 0; seed++) {
            GameEngine candidate = new GameEngine(seed, 0);
            for (int slot = 0; slot < 3; slot++) {
                if (candidate.getPiece(slot).size() == 1) {
                    game = candidate;
                    singleSlot = slot;
                    break;
                }
            }
        }
        assertNotNull(game);
        Field boardField = GameEngine.class.getDeclaredField("board");
        boardField.setAccessible(true);
        int[][] board = (int[][]) boardField.get(game);
        for (int i = 1; i < 8; i++) {
            board[0][i] = 2;
            board[i][0] = 3;
        }
        assertTrue(game.place(singleSlot, 0, 0));
        assertEquals(2, game.getLastClearedLines());
        assertEquals(15, game.getLastClearedCells());
        assertEquals(150, game.getScore());
        for (int[] row : game.copyBoard()) for (int value : row) assertEquals(0, value);
    }

    @Test public void clearedLinesDoNotPullOtherBlocksDownAndComboResets() throws Exception {
        GameEngine game = null;
        int singleSlot = -1;
        for (long seed = 0; seed < 500 && singleSlot < 0; seed++) {
            GameEngine candidate = new GameEngine(seed, 0);
            for (int slot = 0; slot < 3; slot++) {
                if (candidate.getPiece(slot).size() == 1) {
                    game = candidate;
                    singleSlot = slot;
                    break;
                }
            }
        }
        assertNotNull(game);
        Field boardField = GameEngine.class.getDeclaredField("board");
        boardField.setAccessible(true);
        int[][] board = (int[][]) boardField.get(game);
        for (int col = 1; col < 8; col++) board[0][col] = 2;
        board[6][6] = 4;

        assertTrue(game.place(singleSlot, 0, 0));
        assertEquals(1, game.getCombo());
        assertEquals(80, game.getScore());
        assertEquals(4, game.getCell(6, 6)); // no gravity after the row disappears

        int nextSlot = (singleSlot + 1) % 3;
        assertTrue(game.place(nextSlot, 0, 0));
        assertEquals(0, game.getCombo()); // a turn without a clear breaks the streak
        assertEquals(4, game.getCell(6, 6));
    }

    @Test public void bestScoreNeverFallsBelowCurrentScore() {
        GameEngine game = new GameEngine(2L, 500);
        assertTrue(game.getBestScore() >= game.getScore());
        game.restart();
        assertEquals(500, game.getBestScore());
    }
}
