package com.minoza.game;

import android.animation.ValueAnimator;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.os.Build;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.DecelerateInterpolator;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;

/** Full-screen MINOZA BLOCKS interface, custom-drawn to keep it crisp on small phones. */
public final class GameView extends View {
    private static final int HOME = 0;
    private static final int PLAY = 1;
    private static final int PAUSE = 2;
    private static final int SETTINGS = 3;
    private static final int OVER = 4;
    private static final int[] GEM_COLORS = {
            0xff32c8ff, 0xff3869ee, 0xfff04a4d,
            0xff9a4bea, 0xffff8a28, 0xffffc83e
    };

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final SharedPreferences preferences;
    private final SoundEngine sound = new SoundEngine();
    private final Random visualRandom = new Random(43L);
    private final RectF[] trayBounds = {new RectF(), new RectF(), new RectF()};
    private final RectF homePlay = new RectF();
    private final RectF homeSettings = new RectF();
    private final RectF gamePause = new RectF();
    private final RectF gameSettings = new RectF();
    private final RectF settingsBack = new RectF();
    private final RectF soundToggle = new RectF();
    private final RectF vibrationToggle = new RectF();
    private final RectF resumeButton = new RectF();
    private final RectF restartButton = new RectF();
    private final RectF homeButton = new RectF();
    private final RectF retryButton = new RectF();
    private final RectF overHomeButton = new RectF();

    private GameEngine engine;
    private int screen = HOME;
    private int settingsReturnScreen = HOME;
    private int bestScore;
    private boolean recordReached;
    private boolean soundEnabled;
    private boolean vibrationEnabled;
    private boolean dragging;
    private int dragSlot = -1;
    private float dragX;
    private float dragY;
    private float boardLeft;
    private float boardTop;
    private float boardSize;
    private float cellSize;
    private float density;
    private float screenFade = 1f;
    private long clearStarted;
    private boolean[][] clearMask;
    private final ArrayList<Particle> particles = new ArrayList<>();
    private ValueAnimator transitionAnimator;

    private static final class Particle {
        float x, y, vx, vy, radius;
        int color;
        long born;
        int life;
    }

    public GameView(Context context) {
        super(context);
        density = getResources().getDisplayMetrics().density;
        preferences = context.getSharedPreferences("minozablocks", Context.MODE_PRIVATE);
        bestScore = preferences.getInt("best_score", 0);
        soundEnabled = preferences.getBoolean("sound_enabled", true);
        vibrationEnabled = preferences.getBoolean("vibration_enabled", true);
        sound.setEnabled(soundEnabled);
        engine = new GameEngine(System.nanoTime(), bestScore);
        recordReached = false;
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        setFocusable(true);
        setFocusableInTouchMode(true);
    }

    @Override protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        calculateLayout(w, h);
    }

    private void calculateLayout(float w, float h) {
        float margin = w * .052f;
        boardSize = Math.min(w - margin * 2f, h * .43f);
        boardLeft = (w - boardSize) / 2f;
        boardTop = Math.max(h * .255f, 145f * density);
        // On shorter displays, preserve room for the three-piece tray.
        if (boardTop + boardSize > h * .70f) boardTop = h * .70f - boardSize;
        boardTop = Math.max(105f * density, boardTop);
        cellSize = boardSize / GameEngine.SIZE;

        float icon = 52f * density;
        homeSettings.set(w - icon - 18f * density, 35f * density,
                w - 14f * density, 35f * density + icon);
        gameSettings.set(homeSettings);
        gamePause.set(w - icon * 2f - 28f * density, 35f * density,
                w - icon - 28f * density, 35f * density + icon);
        settingsBack.set(18f * density, 34f * density, 78f * density, 94f * density);
        homePlay.set(w * .12f, h * .665f, w * .88f, h * .665f + 72f * density);
        float slotWidth = (w - margin * 2f) / 3f;
        float trayY = boardTop + boardSize + Math.max(64f * density, h * .055f);
        for (int i = 0; i < 3; i++) {
            float left = margin + i * slotWidth;
            trayBounds[i].set(left + 4f * density, trayY - 26f * density,
                    left + slotWidth - 4f * density, trayY + 108f * density);
        }
        float cardW = w * .78f;
        float cardL = (w - cardW) / 2f;
        float settingsY = h * .37f;
        soundToggle.set(cardL + 18f * density, settingsY, cardL + cardW - 18f * density, settingsY + 62f * density);
        vibrationToggle.set(cardL + 18f * density, settingsY + 82f * density, cardL + cardW - 18f * density, settingsY + 144f * density);
        float buttonW = w * .72f;
        float buttonL = (w - buttonW) / 2f;
        resumeButton.set(buttonL, h * .49f, buttonL + buttonW, h * .49f + 62f * density);
        restartButton.set(buttonL, h * .58f, buttonL + buttonW, h * .58f + 58f * density);
        homeButton.set(buttonL, h * .67f, buttonL + buttonW, h * .67f + 58f * density);
        retryButton.set(buttonL, h * .615f, buttonL + buttonW, h * .615f + 58f * density);
        overHomeButton.set(w * .28f, h * .695f, w * .72f, h * .695f + 42f * density);
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float w = getWidth();
        float h = getHeight();
        if (w <= 0 || h <= 0) return;
        drawBackground(canvas, w, h);
        switch (screen) {
            case HOME: drawHome(canvas, w, h); break;
            case PLAY: drawGame(canvas, w, h); break;
            case SETTINGS:
                if (settingsReturnScreen == PLAY) drawGame(canvas, w, h);
                else drawHome(canvas, w, h);
                drawSettingsOverlay(canvas, w, h);
                break;
            case PAUSE:
                drawGame(canvas, w, h);
                drawPauseOverlay(canvas, w, h);
                break;
            case OVER:
                drawGame(canvas, w, h);
                drawGameOver(canvas, w, h);
                break;
        }
        drawParticles(canvas);
        if (screenFade < 1f) {
            paint.setShader(null);
            paint.setColor(Color.argb((int) ((1f - screenFade) * 70), 12, 20, 52));
            canvas.drawRect(0, 0, w, h, paint);
        }
    }

    private void drawBackground(Canvas c, float w, float h) {
        paint.setShader(new LinearGradient(0, 0, w * .55f, h,
                new int[]{0xff405da5, 0xff354f94, 0xff2a417f}, null, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, w, h, paint);
        paint.setShader(null);
        paint.setColor(0x1239cfff);
        c.drawCircle(w * .14f, h * .22f, w * .62f, paint);
        paint.setColor(0x0d9bbaff);
        c.drawCircle(w * .91f, h * .69f, w * .55f, paint);
        // A restrained dust field gives the blue background depth without clutter.
        for (int i = 0; i < 30; i++) {
            float x = (float) ((i * 83L + 29L) % 997L) / 997f * w;
            float y = (float) ((i * 137L + 67L) % 991L) / 991f * h;
            float r = (i % 5 == 0 ? 1.6f : .8f) * density;
            paint.setColor(i % 3 == 0 ? 0x35ffffff : 0x1affffff);
            c.drawCircle(x, y, r, paint);
        }
    }

    private void drawHome(Canvas c, float w, float h) {
        drawCrown(c, w * .12f, h * .071f, 26f * density);
        drawText(c, "" + bestScore, w * .19f, h * .079f, 21f * density, 0xffffd55c, true, Paint.Align.LEFT);
        drawGear(c, homeSettings.centerX(), homeSettings.centerY(), 23f * density);

        float logoY = h * .245f;
        drawLogo(c, w / 2f, logoY, Math.min(w * .31f, 132f * density));
        drawText(c, "MINOZA", w / 2f, h * .365f, 39f * density, Color.WHITE, true, Paint.Align.CENTER);
        drawText(c, "BLOCKS", w / 2f, h * .407f, 24f * density, 0xff8beaff, true, Paint.Align.CENTER);
        drawText(c, "THE JEWEL BLOCK CHALLENGE", w / 2f, h * .445f, 10f * density, 0xffd5e4ff, true, Paint.Align.CENTER);

        RectF info = new RectF(w * .12f, h * .515f, w * .88f, h * .615f);
        drawGlassCard(c, info, 0x30202c65);
        drawText(c, "BEST RUN", info.left + 22f * density, info.centerY() - 2f * density,
                11f * density, 0xffb7c9f6, true, Paint.Align.LEFT);
        drawText(c, "" + bestScore, info.left + 22f * density, info.centerY() + 25f * density,
                22f * density, Color.WHITE, true, Paint.Align.LEFT);
        drawText(c, "8 × 8", info.right - 22f * density, info.centerY() + 4f * density,
                21f * density, 0xff9ceaff, true, Paint.Align.RIGHT);

        drawButton(c, homePlay, "PLAY NOW", "", true);
        drawText(c, "NO TIMER     •     PURE PUZZLE", w / 2f, h * .79f,
                10f * density, 0x9ee7efff, true, Paint.Align.CENTER);
        drawText(c, "MADE TO PLAY. BUILT TO SHINE.", w / 2f, h * .925f,
                9f * density, 0x75ffffff, true, Paint.Align.CENTER);
    }

    private void drawGame(Canvas c, float w, float h) {
        drawCrown(c, w * .12f, h * .075f, 23f * density);
        drawText(c, "" + bestScore, w * .19f, h * .084f, 20f * density, 0xffffd45c, true, Paint.Align.LEFT);
        drawPauseGlyph(c, gamePause.centerX(), gamePause.centerY(), 10f * density);
        drawGear(c, gameSettings.centerX(), gameSettings.centerY(), 22f * density);
        drawText(c, "" + engine.getScore(), w / 2f, h * .185f,
                62f * density, Color.WHITE, true, Paint.Align.CENTER);
        if (engine.getCombo() > 1) {
            RectF combo = new RectF(w * .37f, h * .205f, w * .63f, h * .245f);
            drawGlassCard(c, combo, 0x995d39b5);
            drawText(c, "" + engine.getCombo() + "× COMBO", combo.centerX(), combo.centerY() + 4f * density,
                    11f * density, 0xffffe5a1, true, Paint.Align.CENTER);
        }
        drawBoard(c);
        float labelY = boardTop + boardSize + 34f * density;
        drawText(c, "DRAG A PIECE ONTO THE BOARD", w / 2f, labelY,
                10f * density, 0xbfe4eeff, true, Paint.Align.CENTER);
        drawTray(c);
        if (dragging && dragSlot >= 0) drawDragPreview(c);
    }

    private void drawBoard(Canvas c) {
        RectF outer = new RectF(boardLeft - 4f * density, boardTop - 4f * density,
                boardLeft + boardSize + 4f * density, boardTop + boardSize + 4f * density);
        paint.setShader(null);
        paint.setColor(0xff17234f);
        paint.setShadowLayer(13f * density, 0, 7f * density, 0x660d163b);
        c.drawRoundRect(outer, 12f * density, 12f * density, paint);
        paint.clearShadowLayer();
        paint.setShader(new LinearGradient(0, outer.top, 0, outer.bottom,
                0xff222f65, 0xff101a43, Shader.TileMode.CLAMP));
        c.drawRoundRect(outer, 11f * density, 11f * density, paint);
        paint.setShader(null);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(2f * density);
        paint.setColor(0xff647bb9);
        c.drawRoundRect(outer, 11f * density, 11f * density, paint);
        paint.setStyle(Paint.Style.FILL);

        for (int r = 0; r < GameEngine.SIZE; r++) {
            for (int col = 0; col < GameEngine.SIZE; col++) {
                float x = boardLeft + col * cellSize;
                float y = boardTop + r * cellSize;
                RectF square = new RectF(x + 1.2f * density, y + 1.2f * density,
                        x + cellSize - 1.2f * density, y + cellSize - 1.2f * density);
                paint.setShader(new LinearGradient(x, y, x, y + cellSize,
                        0xff1d2a5b, 0xff19234e, Shader.TileMode.CLAMP));
                c.drawRoundRect(square, 4f * density, 4f * density, paint);
                paint.setShader(null);
                paint.setStyle(Paint.Style.STROKE);
                paint.setStrokeWidth(.8f * density);
                paint.setColor(0x332b3d78);
                c.drawRoundRect(square, 4f * density, 4f * density, paint);
                paint.setStyle(Paint.Style.FILL);
                int color = engine.getCell(r, col);
                if (color > 0) drawGem(c, x + 1.5f * density, y + 1.5f * density,
                        cellSize - 3f * density, GEM_COLORS[(color - 1) % GEM_COLORS.length], 1f);
            }
        }
        drawClearFlash(c);
    }

    private void drawClearFlash(Canvas c) {
        if (clearMask == null) return;
        float t = Math.min(1f, (System.currentTimeMillis() - clearStarted) / 440f);
        int alpha = (int) (155 * (1f - t));
        for (int r = 0; r < GameEngine.SIZE; r++) {
            for (int col = 0; col < GameEngine.SIZE; col++) {
                if (!clearMask[r][col]) continue;
                float x = boardLeft + col * cellSize;
                float y = boardTop + r * cellSize;
                paint.setColor(Color.argb(alpha, 134, 244, 255));
                paint.setStyle(Paint.Style.STROKE);
                paint.setStrokeWidth((2.2f + 3f * (1f - t)) * density);
                c.drawRoundRect(x + 2f * density, y + 2f * density,
                        x + cellSize - 2f * density, y + cellSize - 2f * density,
                        5f * density, 5f * density, paint);
            }
        }
        paint.setStyle(Paint.Style.FILL);
        if (t >= 1f) clearMask = null;
        else postInvalidateOnAnimation();
    }

    private void drawTray(Canvas c) {
        for (int slot = 0; slot < GameEngine.TRAY_SIZE; slot++) {
            RectF bounds = trayBounds[slot];
            boolean used = engine.isUsed(slot);
            if (!used) {
                paint.setColor(0x13202e67);
                c.drawRoundRect(bounds, 10f * density, 10f * density, paint);
            }
            GameEngine.Piece piece = engine.getPiece(slot);
            if (piece == null) continue;
            float availableW = bounds.width() - 18f * density;
            float availableH = bounds.height() - 25f * density;
            float size = Math.min(cellSize * .34f,
                    Math.min(availableW / (piece.width + .15f), availableH / (piece.height + .15f)));
            float left = bounds.centerX() - piece.width * size / 2f;
            float top = bounds.centerY() - piece.height * size / 2f;
            float alpha = used || (dragging && dragSlot == slot) ? .22f : 1f;
            for (int[] block : piece.cells) {
                drawGem(c, left + block[0] * size, top + block[1] * size,
                        size - 1.4f * density, GEM_COLORS[(piece.color - 1) % GEM_COLORS.length], alpha);
            }
        }
    }

    private void drawDragPreview(Canvas c) {
        GameEngine.Piece piece = engine.getPiece(dragSlot);
        if (piece == null) return;
        int[] anchor = dragAnchor(piece);
        int col = anchor[0], row = anchor[1];
        boolean valid = engine.canPlaceInSlot(dragSlot, col, row);
        float previewSize = cellSize;
        int color = valid ? 0xff8af2ff : 0xffff6a77;
        for (int[] block : piece.cells) {
            int xCell = col + block[0];
            int yCell = row + block[1];
            if (xCell < 0 || xCell >= 8 || yCell < 0 || yCell >= 8) continue;
            float x = boardLeft + xCell * previewSize;
            float y = boardTop + yCell * previewSize;
            paint.setColor(valid ? 0x5b8aefff : 0x60ff5268);
            c.drawRoundRect(x + 2f * density, y + 2f * density,
                    x + previewSize - 2f * density, y + previewSize - 2f * density,
                    5f * density, 5f * density, paint);
            paint.setColor(color);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(2f * density);
            c.drawRoundRect(x + 2f * density, y + 2f * density,
                    x + previewSize - 2f * density, y + previewSize - 2f * density,
                    5f * density, 5f * density, paint);
            paint.setStyle(Paint.Style.FILL);
        }
        // Lift the piece preview above the finger so the target stays visible.
        float liftY = dragY - 52f * density;
        float liftX = dragX;
        float shadow = Math.min(cellSize * .37f, 34f * density);
        paint.setColor(0x7f101b43);
        c.drawCircle(liftX, liftY, shadow, paint);
        for (int[] block : piece.cells) {
            float side = Math.min(cellSize * .42f, 34f * density);
            float x = liftX - piece.width * side / 2f + block[0] * side;
            float y = liftY - piece.height * side / 2f + block[1] * side;
            drawGem(c, x, y, side - 1.5f * density,
                    GEM_COLORS[(piece.color - 1) % GEM_COLORS.length], .96f);
        }
    }

    private int[] dragAnchor(GameEngine.Piece piece) {
        float previewCenterY = dragY - 52f * density;
        int col = Math.round((dragX - boardLeft) / cellSize - piece.width / 2f);
        int row = Math.round((previewCenterY - boardTop) / cellSize - piece.height / 2f);
        return new int[]{col, row};
    }

    private void drawSettingsOverlay(Canvas c, float w, float h) {
        drawDim(c, w, h, 150);
        RectF card = new RectF(w * .09f, h * .29f, w * .91f, h * .68f);
        drawPanel(c, card);
        drawText(c, "SETTINGS", w / 2f, card.top + 44f * density,
                25f * density, Color.WHITE, true, Paint.Align.CENTER);
        drawBackArrow(c, settingsBack.centerX(), settingsBack.centerY(), 18f * density);
        drawToggleRow(c, soundToggle, "SOUND EFFECTS", soundEnabled);
        drawToggleRow(c, vibrationToggle, "VIBRATION", vibrationEnabled);
        drawText(c, "YOUR SETTINGS ARE SAVED AUTOMATICALLY", w / 2f,
                card.bottom - 24f * density, 8f * density, 0xffb8c9ef, true, Paint.Align.CENTER);
    }

    private void drawPauseOverlay(Canvas c, float w, float h) {
        drawDim(c, w, h, 168);
        RectF card = new RectF(w * .09f, h * .34f, w * .91f, h * .77f);
        drawPanel(c, card);
        drawText(c, "PAUSED", w / 2f, card.top + 49f * density,
                29f * density, Color.WHITE, true, Paint.Align.CENTER);
        drawText(c, "TAKE YOUR TIME", w / 2f, card.top + 77f * density,
                10f * density, 0xffb7caff, true, Paint.Align.CENTER);
        drawButton(c, resumeButton, "RESUME", "", true);
        drawButton(c, restartButton, "RESTART", "", false);
        drawButton(c, homeButton, "MAIN MENU", "", false);
    }

    private void drawGameOver(Canvas c, float w, float h) {
        drawDim(c, w, h, 178);
        RectF card = new RectF(w * .075f, h * .275f, w * .925f, h * .80f);
        drawPanel(c, card);
        drawLogo(c, w / 2f, card.top + 70f * density, 78f * density);
        drawText(c, "GAME OVER", w / 2f, card.top + 145f * density,
                29f * density, Color.WHITE, true, Paint.Align.CENTER);
        drawText(c, "FINAL SCORE", w / 2f, card.top + 190f * density,
                11f * density, 0xffbbcef7, true, Paint.Align.CENTER);
        drawText(c, "" + engine.getScore(), w / 2f, card.top + 246f * density,
                48f * density, 0xffffdf78, true, Paint.Align.CENTER);
        drawText(c, "BEST  " + bestScore, w / 2f, card.top + 278f * density,
                13f * density, 0xffe5edff, true, Paint.Align.CENTER);
        drawButton(c, retryButton, "PLAY AGAIN", "", true);
        drawButton(c, overHomeButton, "MAIN MENU", "", false);
    }

    private void drawToggleRow(Canvas c, RectF r, String title, boolean on) {
        paint.setColor(0x55263872);
        c.drawRoundRect(r, 12f * density, 12f * density, paint);
        drawText(c, title, r.left + 17f * density, r.centerY() + 5f * density,
                13f * density, 0xfff1f5ff, true, Paint.Align.LEFT);
        RectF toggle = new RectF(r.right - 72f * density, r.centerY() - 13f * density,
                r.right - 15f * density, r.centerY() + 13f * density);
        paint.setColor(on ? 0xff48c7e7 : 0xff46547e);
        c.drawRoundRect(toggle, 18f * density, 18f * density, paint);
        paint.setColor(Color.WHITE);
        float knobX = on ? toggle.right - 14f * density : toggle.left + 14f * density;
        c.drawCircle(knobX, toggle.centerY(), 10f * density, paint);
    }

    private void drawButton(Canvas c, RectF r, String label, String sub, boolean primary) {
        paint.setShader(null);
        paint.setColor(0x55202b61);
        paint.setShadowLayer(12f * density, 0, 6f * density, 0x55202b61);
        c.drawRoundRect(r, 18f * density, 18f * density, paint);
        paint.clearShadowLayer();
        int top = primary ? 0xff65e4ff : 0xff536eae;
        int bottom = primary ? 0xff228cc8 : 0xff3c528f;
        paint.setShader(new LinearGradient(r.left, r.top, r.left, r.bottom,
                top, bottom, Shader.TileMode.CLAMP));
        c.drawRoundRect(r, 18f * density, 18f * density, paint);
        paint.setShader(null);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(1.2f * density);
        paint.setColor(primary ? 0xffc2f6ff : 0xff8095cb);
        c.drawRoundRect(r, 18f * density, 18f * density, paint);
        paint.setStyle(Paint.Style.FILL);
        drawText(c, label, r.centerX(), r.centerY() + (sub.isEmpty() ? 6f : -2f) * density,
                17f * density, primary ? 0xff082b5a : Color.WHITE, true, Paint.Align.CENTER);
        if (!sub.isEmpty()) drawText(c, sub, r.centerX(), r.centerY() + 17f * density,
                8f * density, 0xffd3ecff, true, Paint.Align.CENTER);
    }

    private void drawGlassCard(Canvas c, RectF r, int overlay) {
        paint.setShader(new LinearGradient(r.left, r.top, r.right, r.bottom,
                0x503b5697 | (overlay & 0xff000000), overlay, Shader.TileMode.CLAMP));
        c.drawRoundRect(r, 16f * density, 16f * density, paint);
        paint.setShader(null);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(1f * density);
        paint.setColor(0x445edaff);
        c.drawRoundRect(r, 16f * density, 16f * density, paint);
        paint.setStyle(Paint.Style.FILL);
    }

    private void drawPanel(Canvas c, RectF r) {
        paint.setColor(0x880d1744);
        paint.setShadowLayer(25f * density, 0, 9f * density, 0xaa0b1235);
        c.drawRoundRect(r, 24f * density, 24f * density, paint);
        paint.clearShadowLayer();
        paint.setShader(new LinearGradient(r.left, r.top, r.right, r.bottom,
                0xff263c7d, 0xff182958, Shader.TileMode.CLAMP));
        c.drawRoundRect(r, 24f * density, 24f * density, paint);
        paint.setShader(null);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(1.5f * density);
        paint.setColor(0xff6f8dca);
        c.drawRoundRect(r, 24f * density, 24f * density, paint);
        paint.setStyle(Paint.Style.FILL);
    }

    private void drawDim(Canvas c, float w, float h, int alpha) {
        paint.setColor(Color.argb(alpha, 8, 14, 39));
        c.drawRect(0, 0, w, h, paint);
    }

    private void drawLogo(Canvas c, float cx, float cy, float size) {
        paint.setColor(0x55202a60);
        c.drawCircle(cx, cy + size * .08f, size * .58f, paint);
        float unit = size * .34f;
        drawGem(c, cx - unit * .48f, cy - unit * .88f, unit, 0xffffca55, 1f);
        drawGem(c, cx - unit * 1.22f, cy - unit * .08f, unit, 0xff39c9ff, 1f);
        drawGem(c, cx + unit * .25f, cy - unit * .08f, unit, 0xff9253ed, 1f);
        drawGem(c, cx - unit * .48f, cy + unit * .72f, unit, 0xff3268ec, 1f);
    }

    private void drawGem(Canvas c, float x, float y, float size, int color, float alpha) {
        int a = Math.max(0, Math.min(255, (int) (255f * alpha)));
        int dark = multiplyColor(color, .48f, a);
        int mid = withAlpha(color, a);
        int light = multiplyColor(color, 1.28f, a);
        float inset = Math.max(1f, size * .055f);
        RectF base = new RectF(x + inset, y + inset, x + size - inset, y + size - inset);
        paint.setShader(null);
        paint.setColor(Color.argb((int) (75 * alpha), 7, 14, 42));
        c.drawRoundRect(new RectF(base.left + size * .035f, base.top + size * .075f,
                base.right + size * .035f, base.bottom + size * .075f), size * .10f, size * .10f, paint);
        paint.setShader(new LinearGradient(x, y, x + size * .65f, y + size,
                new int[]{light, mid, dark}, new float[]{0f, .48f, 1f}, Shader.TileMode.CLAMP));
        c.drawRoundRect(base, size * .095f, size * .095f, paint);
        paint.setShader(null);
        Path top = new Path();
        top.moveTo(x + inset, y + inset);
        top.lineTo(x + size - inset, y + inset);
        top.lineTo(x + size * .79f, y + size * .24f);
        top.lineTo(x + size * .20f, y + size * .24f);
        top.close();
        paint.setShader(new LinearGradient(x, y, x, y + size * .25f,
                withAlpha(multiplyColor(color, 1.45f, a), a), withAlpha(multiplyColor(color, 1.08f, a), a), Shader.TileMode.CLAMP));
        c.drawPath(top, paint);
        paint.setShader(null);
        Path left = new Path();
        left.moveTo(x + inset, y + inset);
        left.lineTo(x + size * .20f, y + size * .24f);
        left.lineTo(x + size * .20f, y + size * .79f);
        left.lineTo(x + inset, y + size - inset);
        left.close();
        paint.setColor(withAlpha(multiplyColor(color, 1.12f, a), a));
        c.drawPath(left, paint);
        Path right = new Path();
        right.moveTo(x + size - inset, y + inset);
        right.lineTo(x + size * .79f, y + size * .24f);
        right.lineTo(x + size * .79f, y + size * .80f);
        right.lineTo(x + size - inset, y + size - inset);
        right.close();
        paint.setColor(withAlpha(multiplyColor(color, .62f, a), a));
        c.drawPath(right, paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(Math.max(.8f, size * .018f));
        paint.setColor(Color.argb((int) (100 * alpha), 235, 251, 255));
        c.drawRoundRect(base, size * .095f, size * .095f, paint);
        paint.setStyle(Paint.Style.FILL);
        paint.setStrokeWidth(1f);
        paint.setColor(Color.argb((int) (145 * alpha), 255, 255, 255));
        c.drawLine(x + size * .12f, y + size * .11f, x + size * .67f, y + size * .11f, paint);
        c.drawLine(x + size * .11f, y + size * .16f, x + size * .11f, y + size * .59f, paint);
        paint.setShader(null);
    }

    private int withAlpha(int color, int alpha) { return (color & 0x00ffffff) | (alpha << 24); }
    private int multiplyColor(int color, float factor, int alpha) {
        int r = Math.min(255, (int) (Color.red(color) * factor));
        int g = Math.min(255, (int) (Color.green(color) * factor));
        int b = Math.min(255, (int) (Color.blue(color) * factor));
        return Color.argb(alpha, r, g, b);
    }

    private void drawCrown(Canvas c, float cx, float cy, float size) {
        Path crown = new Path();
        crown.moveTo(cx - size, cy - size * .38f);
        crown.lineTo(cx - size * .55f, cy - size * .04f);
        crown.lineTo(cx - size * .20f, cy - size * .75f);
        crown.lineTo(cx + size * .20f, cy - size * .75f);
        crown.lineTo(cx + size * .55f, cy - size * .04f);
        crown.lineTo(cx + size, cy - size * .38f);
        crown.lineTo(cx + size * .78f, cy + size * .48f);
        crown.lineTo(cx - size * .78f, cy + size * .48f);
        crown.close();
        paint.setColor(0x553c260a);
        c.drawCircle(cx, cy, size * .95f, paint);
        paint.setShader(new LinearGradient(cx, cy - size, cx, cy + size,
                0xffffe97b, 0xffe79b16, Shader.TileMode.CLAMP));
        c.drawPath(crown, paint);
        paint.setShader(null);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(Math.max(1f, size * .075f));
        paint.setColor(0xffffd95b);
        c.drawPath(crown, paint);
        paint.setStyle(Paint.Style.FILL);
        c.drawCircle(cx - size * .2f, cy - size * .75f, size * .17f, paint);
        c.drawCircle(cx + size * .2f, cy - size * .75f, size * .17f, paint);
        paint.setColor(0xfffff4ba);
        c.drawCircle(cx - size * .2f, cy - size * .78f, size * .07f, paint);
    }

    private void drawGear(Canvas c, float cx, float cy, float radius) {
        if (radius <= 0) return;
        paint.setColor(0xffbfefff);
        paint.setStrokeWidth(radius * .28f);
        paint.setStrokeCap(Paint.Cap.ROUND);
        for (int i = 0; i < 8; i++) {
            double a = i * Math.PI / 4;
            float x1 = cx + (float) Math.cos(a) * radius * .66f;
            float y1 = cy + (float) Math.sin(a) * radius * .66f;
            float x2 = cx + (float) Math.cos(a) * radius * .98f;
            float y2 = cy + (float) Math.sin(a) * radius * .98f;
            c.drawLine(x1, y1, x2, y2, paint);
        }
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(radius * .28f);
        paint.setColor(0xffc9f1ff);
        c.drawCircle(cx, cy, radius * .56f, paint);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(0xff46689d);
        c.drawCircle(cx, cy, radius * .27f, paint);
        paint.setStrokeCap(Paint.Cap.BUTT);
    }

    private void drawPauseGlyph(Canvas c, float cx, float cy, float size) {
        paint.setShader(null);
        paint.setColor(0xffd8efff);
        c.drawRoundRect(cx - size * .70f, cy - size, cx - size * .18f, cy + size,
                size * .16f, size * .16f, paint);
        c.drawRoundRect(cx + size * .18f, cy - size, cx + size * .70f, cy + size,
                size * .16f, size * .16f, paint);
    }

    private void drawBackArrow(Canvas c, float cx, float cy, float size) {
        paint.setColor(Color.WHITE);
        paint.setStrokeWidth(3f * density);
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setStyle(Paint.Style.STROKE);
        Path path = new Path();
        path.moveTo(cx + size * .55f, cy);
        path.lineTo(cx - size * .55f, cy);
        path.moveTo(cx - size * .55f, cy);
        path.lineTo(cx - size * .05f, cy - size * .48f);
        path.moveTo(cx - size * .55f, cy);
        path.lineTo(cx - size * .05f, cy + size * .48f);
        c.drawPath(path, paint);
        paint.setStyle(Paint.Style.FILL);
        paint.setStrokeCap(Paint.Cap.BUTT);
    }

    private void drawText(Canvas c, String text, float x, float y, float size,
                          int color, boolean bold, Paint.Align align) {
        paint.setShader(null);
        paint.setColor(color);
        paint.setTextSize(size);
        paint.setTypeface(bold ? android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.BOLD)
                : android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.NORMAL));
        paint.setTextAlign(align);
        paint.setStyle(Paint.Style.FILL);
        paint.setShadowLayer(1.5f * density, 0, 1f * density, 0x44202b54);
        c.drawText(text, x, y, paint);
        paint.clearShadowLayer();
    }

    private void playEffect(int effect) {
        sound.play(effect);
        if (vibrationEnabled) {
            try {
                Vibrator vibrator = (Vibrator) getContext().getSystemService(Context.VIBRATOR_SERVICE);
                if (vibrator != null && vibrator.hasVibrator()) {
                    long ms = effect == 4 || effect == 5 || effect == 7 ? 42 : 16;
                    if (Build.VERSION.SDK_INT >= 26) vibrator.vibrate(VibrationEffect.createOneShot(ms, effect == 4 ? 150 : 75));
                    else vibrator.vibrate(ms);
                }
            } catch (Exception ignored) { }
        }
    }

    private void saveBestIfNeeded() {
        if (engine.getScore() > bestScore) {
            bestScore = engine.getScore();
            preferences.edit().putInt("best_score", bestScore).apply();
            if (!recordReached) {
                recordReached = true;
                playEffect(7);
            }
        }
    }

    private void startNewGame() {
        engine = new GameEngine(System.nanoTime(), bestScore);
        recordReached = false;
        clearMask = null;
        particles.clear();
        dragging = false;
        dragSlot = -1;
        playEffect(8);
        changeScreen(PLAY);
    }

    private void changeScreen(int next) {
        screen = next;
        if (transitionAnimator != null) transitionAnimator.cancel();
        screenFade = .55f;
        transitionAnimator = ValueAnimator.ofFloat(.55f, 1f);
        transitionAnimator.setDuration(230);
        transitionAnimator.setInterpolator(new DecelerateInterpolator());
        transitionAnimator.addUpdateListener(a -> {
            screenFade = (Float) a.getAnimatedValue();
            postInvalidateOnAnimation();
        });
        transitionAnimator.start();
        invalidate();
    }

    private void spawnClearParticles() {
        if (clearMask == null) return;
        long now = System.currentTimeMillis();
        for (int r = 0; r < 8; r++) for (int col = 0; col < 8; col++) {
            if (!clearMask[r][col]) continue;
            for (int n = 0; n < 2; n++) {
                Particle p = new Particle();
                p.x = boardLeft + (col + .5f) * cellSize;
                p.y = boardTop + (r + .5f) * cellSize;
                p.vx = (visualRandom.nextFloat() - .5f) * 220f * density;
                p.vy = (-.35f - visualRandom.nextFloat()) * 230f * density;
                p.radius = (2f + visualRandom.nextFloat() * 3f) * density;
                p.color = GEM_COLORS[visualRandom.nextInt(GEM_COLORS.length)];
                p.born = now;
                p.life = 420 + visualRandom.nextInt(260);
                particles.add(p);
            }
        }
    }

    private void drawParticles(Canvas c) {
        long now = System.currentTimeMillis();
        Iterator<Particle> it = particles.iterator();
        while (it.hasNext()) {
            Particle p = it.next();
            float t = (now - p.born) / (float) p.life;
            if (t >= 1f) { it.remove(); continue; }
            float x = p.x + p.vx * t * .28f;
            float y = p.y + p.vy * t * .28f + 100f * density * t * t;
            paint.setColor((p.color & 0x00ffffff) | (((int) (220 * (1f - t))) << 24));
            c.drawCircle(x, y, p.radius * (1f - .45f * t), paint);
        }
        if (!particles.isEmpty()) postInvalidateOnAnimation();
    }

    @Override public boolean onTouchEvent(MotionEvent event) {
        float x = event.getX();
        float y = event.getY();
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                if (screen == HOME) {
                    if (homeSettings.contains(x, y)) { settingsReturnScreen = HOME; playEffect(0); changeScreen(SETTINGS); }
                    else if (homePlay.contains(x, y)) startNewGame();
                    else playEffect(0);
                } else if (screen == PLAY) {
                    if (gameSettings.contains(x, y)) {
                        dragging = false;
                        settingsReturnScreen = PLAY;
                        playEffect(0);
                        changeScreen(SETTINGS);
                    } else if (gamePause.contains(x, y)) {
                        dragging = false;
                        playEffect(0);
                        changeScreen(PAUSE);
                    } else {
                        for (int i = 0; i < 3; i++) {
                            if (trayBounds[i].contains(x, y) && !engine.isUsed(i)) {
                                dragSlot = i;
                                dragging = true;
                                dragX = x;
                                dragY = y;
                                playEffect(1);
                                invalidate();
                                return true;
                            }
                        }
                        playEffect(0);
                    }
                } else if (screen == SETTINGS) {
                    if (settingsBack.contains(x, y)) { playEffect(0); changeScreen(settingsReturnScreen); }
                    else if (soundToggle.contains(x, y)) {
                        soundEnabled = !soundEnabled;
                        sound.setEnabled(soundEnabled);
                        preferences.edit().putBoolean("sound_enabled", soundEnabled).apply();
                        if (soundEnabled) playEffect(0);
                        invalidate();
                    } else if (vibrationToggle.contains(x, y)) {
                        vibrationEnabled = !vibrationEnabled;
                        preferences.edit().putBoolean("vibration_enabled", vibrationEnabled).apply();
                        if (soundEnabled) playEffect(0);
                        invalidate();
                    }
                } else if (screen == PAUSE) {
                    if (resumeButton.contains(x, y)) { playEffect(0); changeScreen(PLAY); }
                    else if (restartButton.contains(x, y)) startNewGame();
                    else if (homeButton.contains(x, y)) { playEffect(8); changeScreen(HOME); }
                } else if (screen == OVER) {
                    if (retryButton.contains(x, y)) startNewGame();
                    else if (overHomeButton.contains(x, y)) { playEffect(8); changeScreen(HOME); }
                }
                return true;
            case MotionEvent.ACTION_MOVE:
                if (dragging) {
                    dragX = x;
                    dragY = y;
                    invalidate();
                }
                return true;
            case MotionEvent.ACTION_UP:
                if (dragging && dragSlot >= 0) {
                    dragX = x;
                    dragY = y;
                    GameEngine.Piece piece = engine.getPiece(dragSlot);
                    int[] anchor = dragAnchor(piece);
                    boolean fingerOverBoard = x >= boardLeft - cellSize * .4f
                            && x <= boardLeft + boardSize + cellSize * .4f
                            && y >= boardTop - cellSize * .2f
                            && y <= boardTop + boardSize + cellSize * .5f;
                    boolean placed = fingerOverBoard && engine.place(dragSlot, anchor[0], anchor[1]);
                    if (placed) {
                        playEffect(engine.getLastClearedCells() > 0 ? (engine.getCombo() > 1 ? 5 : 4) : 2);
                        if (engine.getLastClearedCells() > 0) {
                            clearMask = engine.copyLastClearMask();
                            clearStarted = System.currentTimeMillis();
                            spawnClearParticles();
                        }
                        saveBestIfNeeded();
                        if (engine.isGameOver()) {
                            saveBestIfNeeded();
                            playEffect(6);
                            changeScreen(OVER);
                        }
                    } else {
                        playEffect(3);
                    }
                    dragging = false;
                    dragSlot = -1;
                    invalidate();
                }
                return true;
            case MotionEvent.ACTION_CANCEL:
                dragging = false;
                dragSlot = -1;
                invalidate();
                return true;
        }
        return true;
    }

    public boolean handleBack() {
        if (screen == SETTINGS) { changeScreen(settingsReturnScreen); return true; }
        if (screen == PLAY) { changeScreen(PAUSE); return true; }
        if (screen == PAUSE) { changeScreen(PLAY); return true; }
        if (screen == OVER) { changeScreen(HOME); return true; }
        return false;
    }

    public void onHostPause() {
        if (screen == PLAY && !dragging) changeScreen(PAUSE);
    }

    public void release() {
        if (transitionAnimator != null) transitionAnimator.cancel();
    }
}
