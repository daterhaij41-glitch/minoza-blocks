package com.minoza.game;

import java.util.Random;

/** Pure game rules. Rendering and Android input are deliberately kept outside this class. */
public final class GameEngine {
    public static final int SIZE = 8;
    public static final int TRAY_SIZE = 3;
    private static final int[][][] SHAPES = new int[][][] {
        {{0,0}},
        {{0,0},{1,0}},
        {{0,0},{1,0},{2,0}},
        {{0,0},{0,1},{1,1}},
        {{0,0},{1,0},{2,0},{3,0}},
        {{0,0},{0,1},{0,2},{1,2}},
        {{0,0},{1,0},{0,1},{1,1}},
        {{0,0},{1,0},{2,0},{1,1}},
        {{1,0},{0,1},{1,1},{2,1}},
        {{0,0},{1,0},{1,1},{2,1}},
        {{0,0},{0,1},{1,1},{2,1}},
        {{0,0},{1,0},{2,0},{0,1},{0,2}},
        {{0,0},{1,0},{0,1},{1,1},{0,2}},
        {{0,0},{1,0},{2,0},{3,0},{4,0}},
        {{0,0},{1,0},{2,0},{1,1},{1,2}},
        {{0,0},{1,0},{2,0},{0,1},{2,1}},
        {{0,0},{0,1},{0,2},{0,3},{1,3}},
        {{1,0},{2,0},{0,1},{1,1},{1,2}}
    };
    private static final int[] COLOR_IDS = {1, 2, 3, 4, 5, 6};

    public static final class Piece {
        public final int[][] cells;
        public final int width;
        public final int height;
        public final int color;
        private Piece(int[][] source, int color) {
            cells = new int[source.length][2];
            int maxX = 0, maxY = 0;
            for (int i = 0; i < source.length; i++) {
                cells[i][0] = source[i][0];
                cells[i][1] = source[i][1];
                maxX = Math.max(maxX, source[i][0]);
                maxY = Math.max(maxY, source[i][1]);
            }
            width = maxX + 1;
            height = maxY + 1;
            this.color = color;
        }
        public int size() { return cells.length; }
    }

    private final Random random;
    private final int[][] board = new int[SIZE][SIZE];
    private final Piece[] tray = new Piece[TRAY_SIZE];
    private final boolean[] used = new boolean[TRAY_SIZE];
    private final boolean[][] lastClearMask = new boolean[SIZE][SIZE];
    private int score;
    private int bestScore;
    private int combo;
    private int moves;
    private int lastClearedCells;
    private int lastClearedLines;
    private boolean gameOver;

    public GameEngine(long seed, int bestScore) {
        random = new Random(seed);
        this.bestScore = Math.max(0, bestScore);
        newBatch();
    }

    public void restart() {
        for (int r = 0; r < SIZE; r++) for (int c = 0; c < SIZE; c++) board[r][c] = 0;
        score = 0;
        combo = 0;
        moves = 0;
        lastClearedCells = 0;
        lastClearedLines = 0;
        for (int r = 0; r < SIZE; r++) for (int c = 0; c < SIZE; c++) lastClearMask[r][c] = false;
        gameOver = false;
        newBatch();
    }

    private void newBatch() {
        for (int i = 0; i < TRAY_SIZE; i++) {
            int shapeIndex = random.nextInt(SHAPES.length);
            int color = COLOR_IDS[random.nextInt(COLOR_IDS.length)];
            tray[i] = new Piece(SHAPES[shapeIndex], color);
            used[i] = false;
        }
    }

    public int getCell(int row, int col) { return board[row][col]; }
    public int[][] copyBoard() {
        int[][] copy = new int[SIZE][SIZE];
        for (int r = 0; r < SIZE; r++) System.arraycopy(board[r], 0, copy[r], 0, SIZE);
        return copy;
    }
    public Piece getPiece(int slot) { return slot < 0 || slot >= TRAY_SIZE ? null : tray[slot]; }
    public boolean isUsed(int slot) { return slot < 0 || slot >= TRAY_SIZE || used[slot]; }
    public int getScore() { return score; }
    public int getBestScore() { return bestScore; }
    public int getCombo() { return combo; }
    public int getMoves() { return moves; }
    public int getLastClearedCells() { return lastClearedCells; }
    public int getLastClearedLines() { return lastClearedLines; }
    public boolean isGameOver() { return gameOver; }
    public boolean isBatchFinished() { return used[0] && used[1] && used[2]; }

    public boolean canPlace(Piece piece, int col, int row) {
        if (piece == null || col < 0 || row < 0 || col + piece.width > SIZE || row + piece.height > SIZE) return false;
        for (int[] cell : piece.cells) {
            if (board[row + cell[1]][col + cell[0]] != 0) return false;
        }
        return true;
    }

    public boolean canPlaceInSlot(int slot, int col, int row) {
        return slot >= 0 && slot < TRAY_SIZE && !used[slot] && !gameOver && canPlace(tray[slot], col, row);
    }

    /** Places one fixed-orientation piece, then clears all completed rows and columns simultaneously. */
    public boolean place(int slot, int col, int row) {
        if (!canPlaceInSlot(slot, col, row)) return false;
        Piece piece = tray[slot];
        for (int[] cell : piece.cells) board[row + cell[1]][col + cell[0]] = piece.color;

        boolean[] fullRows = new boolean[SIZE];
        boolean[] fullCols = new boolean[SIZE];
        for (int r = 0; r < SIZE; r++) {
            boolean full = true;
            for (int c = 0; c < SIZE; c++) if (board[r][c] == 0) { full = false; break; }
            fullRows[r] = full;
        }
        for (int c = 0; c < SIZE; c++) {
            boolean full = true;
            for (int r = 0; r < SIZE; r++) if (board[r][c] == 0) { full = false; break; }
            fullCols[c] = full;
        }

        for (int r = 0; r < SIZE; r++) for (int c = 0; c < SIZE; c++) lastClearMask[r][c] = false;
        lastClearedCells = 0;
        lastClearedLines = 0;
        for (int r = 0; r < SIZE; r++) if (fullRows[r]) lastClearedLines++;
        for (int c = 0; c < SIZE; c++) if (fullCols[c]) lastClearedLines++;
        for (int r = 0; r < SIZE; r++) {
            for (int c = 0; c < SIZE; c++) {
                if (fullRows[r] || fullCols[c]) {
                    lastClearMask[r][c] = true;
                    lastClearedCells++;
                }
            }
        }
        if (lastClearedCells > 0) {
            combo++;
            score += lastClearedCells * 10;
            if (score > bestScore) bestScore = score;
            for (int r = 0; r < SIZE; r++) {
                for (int c = 0; c < SIZE; c++) if (lastClearMask[r][c]) board[r][c] = 0;
            }
        } else {
            combo = 0;
        }

        used[slot] = true;
        moves++;
        if (isBatchFinished()) newBatch();
        updateGameOver();
        return true;
    }

    public boolean[][] copyLastClearMask() {
        boolean[][] copy = new boolean[SIZE][SIZE];
        for (int r = 0; r < SIZE; r++) System.arraycopy(lastClearMask[r], 0, copy[r], 0, SIZE);
        return copy;
    }

    private void updateGameOver() {
        gameOver = true;
        for (int slot = 0; slot < TRAY_SIZE; slot++) {
            if (used[slot]) continue;
            Piece p = tray[slot];
            for (int row = 0; row <= SIZE - p.height; row++) {
                for (int col = 0; col <= SIZE - p.width; col++) {
                    if (canPlace(p, col, row)) { gameOver = false; return; }
                }
            }
        }
    }
}
