package com.minoza.game;

import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioTrack;
import java.util.concurrent.atomic.AtomicInteger;

/** Small procedural sound synthesizer: no downloaded sound packs or network required. */
final class SoundEngine {
    private volatile boolean enabled = true;
    private final AtomicInteger activeTracks = new AtomicInteger(0);

    void setEnabled(boolean value) { enabled = value; }
    boolean isEnabled() { return enabled; }

    void play(int type) {
        if (!enabled || activeTracks.get() >= 3) return;
        final float start;
        final float end;
        final int duration;
        final float volume;
        final float sparkle;
        switch (type) {
            case 1: start = 420; end = 860; duration = 115; volume = .30f; sparkle = .20f; break; // pick up
            case 2: start = 210; end = 95; duration = 125; volume = .36f; sparkle = .08f; break; // place
            case 3: start = 210; end = 145; duration = 150; volume = .25f; sparkle = .02f; break; // invalid
            case 4: start = 520; end = 1420; duration = 310; volume = .32f; sparkle = .35f; break; // clear
            case 5: start = 740; end = 1780; duration = 420; volume = .30f; sparkle = .44f; break; // combo
            case 6: start = 560; end = 105; duration = 750; volume = .31f; sparkle = .05f; break; // game over
            case 7: start = 880; end = 1760; duration = 650; volume = .34f; sparkle = .52f; break; // record
            case 8: start = 310; end = 540; duration = 95; volume = .22f; sparkle = .10f; break; // navigation
            default: start = 920; end = 710; duration = 55; volume = .18f; sparkle = .04f; break; // tap
        }
        activeTracks.incrementAndGet();
        Thread thread = new Thread(() -> synthesize(start, end, duration, volume, sparkle), "Minoza-SFX");
        thread.setDaemon(true);
        thread.start();
    }

    private void synthesize(float start, float end, int durationMs, float volume, float sparkle) {
        AudioTrack track = null;
        try {
            final int sampleRate = 22050;
            final int count = sampleRate * durationMs / 1000;
            short[] pcm = new short[count];
            double phase = 0;
            double shimmerPhase = 0;
            for (int i = 0; i < count; i++) {
                double t = i / (double) count;
                double curve = t * t * (3.0 - 2.0 * t);
                double frequency = start + (end - start) * curve;
                phase += 2.0 * Math.PI * frequency / sampleRate;
                shimmerPhase += 2.0 * Math.PI * (frequency * 2.01) / sampleRate;
                double attack = Math.min(1.0, t * 18.0);
                double decay = Math.pow(1.0 - t, durationMs > 400 ? 1.9 : 2.6);
                double envelope = attack * decay;
                double fundamental = Math.sin(phase);
                double harmonic = Math.sin(phase * 2.0) * .22;
                double shimmer = Math.sin(shimmerPhase) * sparkle;
                double click = (i < sampleRate / 120) ? (Math.random() - .5) * .13 : 0;
                double sample = (fundamental + harmonic + shimmer + click) * envelope * volume;
                pcm[i] = (short) Math.max(Short.MIN_VALUE, Math.min(Short.MAX_VALUE, (int) (sample * 32767)));
            }
            AudioAttributes attributes = new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build();
            AudioFormat format = new AudioFormat.Builder()
                    .setSampleRate(sampleRate)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build();
            track = new AudioTrack.Builder()
                    .setAudioAttributes(attributes)
                    .setAudioFormat(format)
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .setBufferSizeInBytes(pcm.length * 2)
                    .build();
            track.write(pcm, 0, pcm.length);
            track.play();
            Thread.sleep(durationMs + 40L);
        } catch (Exception ignored) {
            // Audio is optional. A muted or unavailable device must never interrupt gameplay.
        } finally {
            if (track != null) {
                try { track.stop(); } catch (Exception ignored) { }
                try { track.release(); } catch (Exception ignored) { }
            }
            activeTracks.decrementAndGet();
        }
    }
}
