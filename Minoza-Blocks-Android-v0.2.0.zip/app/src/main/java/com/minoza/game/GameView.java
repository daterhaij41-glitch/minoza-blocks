package com.minoza.game;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Shader;
import android.os.Build;
import android.view.MotionEvent;
import android.view.View;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Random;

/** A self-contained, offline block puzzle. All art is drawn in code; no external assets or network. */
public class GameView extends View {
    interface ShareCallback { void share(int score); }
    private final ShareCallback shareCallback;
    private final SharedPreferences prefs;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Random random = new Random();

    private static final int N = 8;
    private static final int[][][] SHAPES = {
        {{0,0}}, {{0,0},{0,1}}, {{0,0},{1,0}},
        {{0,0},{0,1},{0,2}}, {{0,0},{1,0},{2,0}},
        {{0,0},{0,1},{1,0}}, {{0,0},{0,1},{1,1}},
        {{0,0},{1,0},{2,0},{3,0}}, {{0,0},{0,1},{0,2},{0,3}},
        {{0,0},{1,0},{0,1},{1,1}},
        {{0,0},{1,0},{2,0},{1,1}}, {{1,0},{0,1},{1,1},{2,1}},
        {{0,0},{1,0},{1,1},{2,1}}, {{1,0},{2,0},{0,1},{1,1}},
        {{0,0},{0,1},{0,2},{1,2}}, {{1,0},{1,1},{1,2},{0,2}},
        {{0,0},{1,0},{2,0},{3,0},{4,0}}, {{0,0},{0,1},{0,2},{0,3},{0,4}},
        {{0,0},{1,0},{2,0},{0,1},{1,1},{2,1}},
        {{0,0},{1,0},{2,0},{2,1},{2,2}}, {{0,0},{0,1},{1,1},{2,1},{2,2}}
    };
    private static final int[] COLORS = {
        0xFF65D8C2, 0xFF76A8FF, 0xFFFFB86B, 0xFFC49BFF,
        0xFFFF7F9B, 0xFF8DDC7B, 0xFFFFD76B, 0xFF56C6E8
    };

    private int[][] board = new int[N][N];
    private int[] tray = new int[3];
    private int[] trayColors = new int[3];
    private boolean[] used = new boolean[3];
    private int score = 0, best = 0, dailyBest = 0, combo = 0, clears = 0, roundIndex = 0;
    private int screen = 0; // 0 home, 1 game, 2 settings, 3 how-to, 4 game over, 5 privacy
    private int selected = -1;
    private boolean dragging = false, moved = false;
    private float pointerX, pointerY, downX, downY;
    private float unit = 1f, logicalH = 900f;
    private float boardX, boardY, cell, boardGap, boardSize, trayY;
    private boolean soundOn = true, hapticsOn = true, lightTheme = false;
    private boolean dailyMode = false, hasSavedGame = false;
    private long sessionSeed = System.currentTimeMillis();
    private int lastLines = 0;
    private final boolean[][] clearFlash = new boolean[N][N];
    private long clearFlashAt = 0L;
    private String toastText = "";
    private long toastUntil = 0;

    public GameView(Context context, ShareCallback callback) {
        super(context);
        shareCallback = callback;
        prefs = context.getSharedPreferences("minoza_local_save", Context.MODE_PRIVATE);
        best = prefs.getInt("best", 0);
        dailyBest = prefs.getInt("daily_best", 0);
        String savedDaily = prefs.getString("daily_date", "");
        String todayDaily = new SimpleDateFormat("yyyyMMdd", Locale.US).format(new Date());
        if (!todayDaily.equals(savedDaily)) { dailyBest = 0; prefs.edit().putInt("daily_best", 0).putString("daily_date", todayDaily).apply(); }
        soundOn = prefs.getBoolean("sound", true);
        hapticsOn = prefs.getBoolean("haptics", true);
        lightTheme = prefs.getBoolean("light", false);
        loadGame();
        setLayerType(View.LAYER_TYPE_HARDWARE, null);
        setFocusable(true);
    }

    private int bg() { return lightTheme ? 0xFFF1F4FA : 0xFF101526; }
    private int panel() { return lightTheme ? 0xFFFFFFFF : 0xFF1B243A; }
    private int panel2() { return lightTheme ? 0xFFE7ECF5 : 0xFF242F49; }
    private int fg() { return lightTheme ? 0xFF17233D : 0xFFF3F6FF; }
    private int muted() { return lightTheme ? 0xFF66738B : 0xFF9AA8C4; }
    private int accent() { return 0xFF65D8C2; }

    @Override protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w,h,oldw,oldh);
        unit = w / 412f;
        logicalH = h / unit;
        cell = Math.min(40f, (392f - 7f * 4f) / 8f);
        boardGap = 4f;
        boardSize = N * cell + (N - 1) * boardGap;
        boardX = (412f - boardSize) / 2f;
        boardY = Math.max(190f, Math.min(logicalH * 0.275f, logicalH - 500f));
        trayY = Math.min(logicalH - 140f, boardY + boardSize + 66f);
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        canvas.save();
        canvas.scale(unit, unit);
        drawBackground(canvas);
        if (screen == 0) drawHome(canvas);
        else if (screen == 1) drawGame(canvas);
        else if (screen == 2) drawSettings(canvas);
        else if (screen == 3) drawHowTo(canvas);
        else if (screen == 5) drawPrivacy(canvas);
        else drawGameOver(canvas);
        if (!toastText.isEmpty() && System.currentTimeMillis() < toastUntil) drawToast(canvas);
        canvas.restore();
        if (!toastText.isEmpty() && System.currentTimeMillis() >= toastUntil) toastText = "";
    }

    private void drawBackground(Canvas c) {
        p.setShader(new LinearGradient(0,0,412,logicalH, lightTheme ? 0xFFF8FAFF : 0xFF18223A,
                lightTheme ? 0xFFE9EEF7 : 0xFF0D1220, Shader.TileMode.CLAMP));
        c.drawRect(0,0,412,logicalH,p); p.setShader(null);
        p.setColor(lightTheme ? 0x1B5E84FF : 0x1456A8FF);
        c.drawCircle(355, 95, 100, p);
        p.setColor(lightTheme ? 0x1671D8C2 : 0x1465D8C2);
        c.drawCircle(24, logicalH-80, 125, p);
    }

    private void text(Canvas c, String s, float x, float y, float size, int color, boolean bold, Paint.Align align) {
        p.setShader(null); p.setColor(color); p.setTextSize(size); p.setTypeface(bold ? android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.BOLD) : android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.NORMAL)); p.setTextAlign(align); p.setStyle(Paint.Style.FILL);
        c.drawText(s,x,y,p);
    }
    private void round(Canvas c,float x,float y,float w,float h,float rad,int color) {
        p.setShader(null); p.setColor(color); p.setStyle(Paint.Style.FILL); c.drawRoundRect(x,y,x+w,y+h,rad,rad,p);
    }
    private void outline(Canvas c,float x,float y,float w,float h,float rad,int color,float sw) {
        p.setShader(null); p.setColor(color); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(sw); c.drawRoundRect(x,y,x+w,y+h,rad,rad,p); p.setStyle(Paint.Style.FILL);
    }
    private void button(Canvas c,String label,float x,float y,float w,float h,boolean primary) {
        round(c,x,y+3,w,h,18,lightTheme?0x180E1C35:0x50000000);
        round(c,x,y,w,h,18,primary?accent():panel2());
        text(c,label,x+w/2,y+h/2+6,16,primary?0xFF102333:fg(),true,Paint.Align.CENTER);
    }
    private void drawLogo(Canvas c,float cx,float top,float size) {
        float s=size/5f; float x=cx-2.5f*s, y=top;
        int[][] logo={{1,0,1},{1,1,1},{1,0,1}};
        for(int row=0;row<3;row++) for(int col=0;col<3;col++) if(logo[row][col]==1) {
            int color=(row+col)%3==0?0xFFFFB86B:(row+col)%3==1?0xFF65D8C2:0xFF76A8FF;
            round(c,x+col*(s+4),y+row*(s+4),s,s,6,color);
        }
    }

    private void drawHome(Canvas c) {
        drawLogo(c,206,58,52);
        text(c,"MINOZA",206,155,36,fg(),true,Paint.Align.CENTER);
        text(c,"BLOCK PUZZLE",206,181,11,muted(),true,Paint.Align.CENTER);
        round(c,26,220,360,106,22,panel());
        text(c,"PERSONAL BEST",48,253,11,muted(),true,Paint.Align.LEFT);
        text(c,format(best),48,302,38,fg(),true,Paint.Align.LEFT);
        round(c,286,244,74,60,16,panel2());
        text(c,"★",323,276,23,0xFFFFD76B,true,Paint.Align.CENTER);
        button(c,"PLAY",42,365,328,62,true);
        button(c, "DAILY CHALLENGE",42,445,328,56,false);
        if (hasSavedGame) button(c,"CONTINUE",42,519,328,52,false);
        float y=hasSavedGame?595:535;
        button(c,"HOW TO PLAY",42,y,156,48,false);
        button(c,"SETTINGS",214,y,156,48,false);
        text(c,"A calm puzzle. A clever mind.",206,logicalH-38,13,muted(),false,Paint.Align.CENTER);
    }

    private void drawGameHeader(Canvas c) {
        text(c,"‹",32,59,34,fg(),false,Paint.Align.CENTER);
        text(c,dailyMode?"DAILY CHALLENGE":"CLASSIC",206,47,12,muted(),true,Paint.Align.CENTER);
        text(c,"↻",380,58,25,fg(),true,Paint.Align.CENTER);
        text(c,"SCORE",206,104,11,muted(),true,Paint.Align.CENTER);
        text(c,format(score),206,151,35,fg(),true,Paint.Align.CENTER);
        round(c,112,166,188,27,13,panel());
        text(c,"BEST  "+format(dailyMode?dailyBest:best),206,184,11,muted(),true,Paint.Align.CENTER);
        if (combo>0) {
            round(c,152,199,108,25,12,0xFF244D53);
            text(c,"COMBO ×"+combo,206,216,11,0xFF8FF5D9,true,Paint.Align.CENTER);
        }
    }

    private void drawBoard(Canvas c) {
        round(c,boardX-9,boardY-9,boardSize+18,boardSize+18,20,panel());
        for(int row=0;row<N;row++) for(int col=0;col<N;col++) {
            float x=boardX+col*(cell+boardGap), y=boardY+row*(cell+boardGap);
            if(board[row][col]==0) round(c,x,y,cell,cell,8,lightTheme?0xFFE6EBF4:0xFF2A3550);
            else drawBlock(c,x,y,cell,board[row][col],1f);
        }

        // Brief amber pulse on cells removed by the last clear.
        if(clearFlashAt>0L) {
            float progress=(android.os.SystemClock.uptimeMillis()-clearFlashAt)/360f;
            if(progress<1f) {
                int alpha=(int)(105f*(1f-progress));
                int flash=Color.argb(Math.max(0,alpha),255,215,107);
                for(int row=0;row<N;row++) for(int col=0;col<N;col++) if(clearFlash[row][col]) {
                    float x=boardX+col*(cell+boardGap), y=boardY+row*(cell+boardGap);
                    round(c,x,y,cell,cell,8,flash);
                }
                postInvalidateDelayed(16);
            } else {
                clearFlashAt=0L;
                for(int row=0;row<N;row++) java.util.Arrays.fill(clearFlash[row],false);
            }
        }

        if (dragging && selected>=0 && isInsideBoard(pointerX,pointerY-64f)) {
            int shape=tray[selected];
            // The floating ghost is 64dp above the finger; target the ghost, not the fingertip.
            int[] pos=placementFromPoint(shape,pointerX,pointerY-64f);
            boolean valid=canPlace(shape,pos[0],pos[1]);
            int color=valid?COLORS[trayColors[selected]%COLORS.length]:0xFFFF667D;

            // Show the exact full rows/columns that will disappear on release.
            if(valid) {
                boolean[] fullRows=new boolean[N], fullCols=new boolean[N];
                for(int row=0;row<N;row++) {
                    fullRows[row]=true;
                    for(int col=0;col<N;col++) if(!filledAfterPreview(row,col,shape,pos[0],pos[1])) { fullRows[row]=false; break; }
                }
                for(int col=0;col<N;col++) {
                    fullCols[col]=true;
                    for(int row=0;row<N;row++) if(!filledAfterPreview(row,col,shape,pos[0],pos[1])) { fullCols[col]=false; break; }
                }
                int hint=Color.argb(82,255,207,94);
                for(int row=0;row<N;row++) for(int col=0;col<N;col++) if(fullRows[row]||fullCols[col]) {
                    float x=boardX+col*(cell+boardGap), y=boardY+row*(cell+boardGap);
                    round(c,x,y,cell,cell,8,hint);
                }
            }

            for(int[] a:SHAPES[shape]) {
                int rr=pos[0]+a[0], cc=pos[1]+a[1];
                if(rr>=0&&rr<N&&cc>=0&&cc<N) {
                    float x=boardX+cc*(cell+boardGap), y=boardY+rr*(cell+boardGap);
                    drawBlock(c,x,y,cell,color,0.50f);
                }
            }
        }
    }

    private boolean filledAfterPreview(int row,int col,int shape,int topRow,int leftCol) {
        if(board[row][col]!=0) return true;
        for(int[] a:SHAPES[shape]) if(topRow+a[0]==row && leftCol+a[1]==col) return true;
        return false;
    }

    private void drawBlock(Canvas c,float x,float y,float size,int color,float alpha) {
        int a=(int)(Color.alpha(color)*alpha); int col=Color.argb(a,Color.red(color),Color.green(color),Color.blue(color));
        round(c,x,y+2,size,size,8,Color.argb((int)(75*alpha),0,0,0));
        round(c,x,y,size,size,8,col);
        p.setColor(Color.argb((int)(70*alpha),255,255,255)); p.setStrokeWidth(1.2f); p.setStyle(Paint.Style.STROKE); c.drawRoundRect(x+2,y+2,x+size-2,y+size-2,7,7,p); p.setStyle(Paint.Style.FILL);
        p.setColor(Color.argb((int)(28*alpha),255,255,255)); c.drawRoundRect(x+5,y+4,x+size-5,y+size*0.34f,5,5,p);
    }

    private void drawTray(Canvas c) {
        text(c,"DRAG A SHAPE ONTO THE BOARD",206,trayY-22,10,muted(),true,Paint.Align.CENTER);
        float slotW=112, start=34;
        for(int i=0;i<3;i++) {
            float x=start+i*124;
            round(c,x,trayY,slotW,88,17,panel());
            if(used[i]) {
                p.setColor(lightTheme?0x558B97AB:0x55808DA8); p.setTextSize(24); p.setTextAlign(Paint.Align.CENTER); c.drawText("✓",x+slotW/2,trayY+50,p);
            } else {
                drawMiniShape(c,tray[i],trayColors[i],x+slotW/2,trayY+43,17f, i==selected && !dragging?1f:0.96f);
            }
            if(i==selected && !used[i]) outline(c,x+1,trayY+1,slotW-2,86,17,accent(),2);
        }
        if (dragging && selected>=0) {
            drawMiniShape(c,tray[selected],trayColors[selected],pointerX,pointerY-64f,27f,0.9f);
        }
        text(c,"Place pieces · Clear lines · Beat your best",206,logicalH-30,11,muted(),false,Paint.Align.CENTER);
    }

    private void drawMiniShape(Canvas c,int shape,int colorIndex,float cx,float cy,float sz,float alpha) {
        int[][] cells=SHAPES[shape]; int maxR=0,maxC=0;
        for(int[] a:cells){maxR=Math.max(maxR,a[0]);maxC=Math.max(maxC,a[1]);}
        float w=(maxC+1)*sz+(maxC)*3, h=(maxR+1)*sz+(maxR)*3;
        float ox=cx-w/2, oy=cy-h/2;
        for(int[] a:cells) drawBlock(c,ox+a[1]*(sz+3),oy+a[0]*(sz+3),sz,COLORS[colorIndex%COLORS.length],alpha);
    }

    private void drawGame(Canvas c) {
        drawGameHeader(c); drawBoard(c); drawTray(c);
        if (selected>=0 && !dragging && !used[selected]) text(c,"Selected",206,trayY+111,10,accent(),true,Paint.Align.CENTER);
    }

    private void drawSettings(Canvas c) {
        text(c,"SETTINGS",206,88,27,fg(),true,Paint.Align.CENTER);
        text(c,"Make the game feel right for you",206,116,12,muted(),false,Paint.Align.CENTER);
        String[] labels={"Sound effects","Haptic feedback","Light appearance"};
        boolean[] values={soundOn,hapticsOn,lightTheme};
        for(int i=0;i<3;i++) {
            float y=176+i*84;
            round(c,28,y,356,64,18,panel());
            text(c,labels[i],50,y+39,15,fg(),true,Paint.Align.LEFT);
            round(c,324,y+17,42,28,15,values[i]?accent():panel2());
            round(c,values[i]?345:327,y+20,22,22,11,0xFFFFFFFF);
            text(c,values[i]?"ON":"OFF",300,y+39,9,muted(),true,Paint.Align.RIGHT);
        }
        button(c,"BACK",42,logicalH-120,328,54,true);
        button(c,"PRIVACY POLICY",42,logicalH-185,328,48,false);
        text(c,"Your best scores are saved on this device.",206,logicalH-42,11,muted(),false,Paint.Align.CENTER);
    }

    private void drawHowTo(Canvas c) {
        text(c,"HOW TO PLAY",206,84,27,fg(),true,Paint.Align.CENTER);
        String[] heads={"1. PLACE", "2. CLEAR", "3. COMBO"};
        String[] desc={"Drag any of 3 fixed shapes. No rotation.","Fill a row or column to clear it. +10 per cell.","Clear on consecutive turns to grow COMBO."};
        for(int i=0;i<3;i++) {
            float y=142+i*142;
            round(c,28,y,356,118,20,panel());
            text(c,heads[i],50,y+34,14,accent(),true,Paint.Align.LEFT);
            text(c,desc[i],50,y+66,12,fg(),false,Paint.Align.LEFT);
        }
        text(c,"Placed blocks stay fixed. No gravity or timer.",206,logicalH-181,11,muted(),false,Paint.Align.CENTER);
        text(c,"The game ends when none of the three pieces fit.",206,logicalH-153,11,muted(),false,Paint.Align.CENTER);
        button(c,"GOT IT",42,logicalH-118,328,54,true);
    }

    private void drawPrivacy(Canvas c) {
        text(c,"PRIVACY",206,75,25,fg(),true,Paint.Align.CENTER);
        round(c,26,112,360,logicalH-270,20,panel());
        String[] lines={"MINOZA BLOCKS — PRIVACY SUMMARY", "", "This version works offline and does not", "collect or transmit personal information.", "", "Scores, settings and the current board", "are stored locally on this device.", "", "No account, ads, analytics or tracking", "SDKs are included in this version.", "", "Uninstalling the app or clearing its", "storage removes locally saved progress.", "", "Before public release, the developer must", "add a monitored contact email and host", "the full privacy policy on a public URL."};
        float yy=153; for(String line:lines){text(c,line,48,yy, line.isEmpty()?8:11, line.startsWith("MINOZA")?accent():fg(), line.startsWith("MINOZA"), Paint.Align.LEFT); yy+=line.isEmpty()?13:22;}
        button(c,"BACK TO SETTINGS",42,logicalH-120,328,54,true);
    }

    private void drawGameOver(Canvas c) {
        drawGame(c);
        round(c,28,logicalH*0.28f,356,logicalH*0.48f,26,panel());
        text(c,"NO MORE MOVES",206,logicalH*0.28f+55,23,fg(),true,Paint.Align.CENTER);
        text(c,"None of the three available pieces can fit.",206,logicalH*0.28f+84,12,muted(),false,Paint.Align.CENTER);
        text(c,"YOUR SCORE",206,logicalH*0.28f+142,11,muted(),true,Paint.Align.CENTER);
        text(c,format(score),206,logicalH*0.28f+195,42,accent(),true,Paint.Align.CENTER);
        text(c,"BEST  "+format(dailyMode?dailyBest:best),206,logicalH*0.28f+223,12,muted(),true,Paint.Align.CENTER);
        button(c,"PLAY AGAIN",52,logicalH*0.28f+260,308,54,true);
        button(c,"SHARE SCORE",52,logicalH*0.28f+328,308,48,false);
        button(c,"HOME",52,logicalH*0.28f+389,308,48,false);
    }

    private void drawToast(Canvas c) {
        round(c,72,logicalH-82,268,38,18,0xE92A3956);
        text(c,toastText,206,logicalH-58,12,0xFFFFFFFF,true,Paint.Align.CENTER);
    }
    private void toast(String s) { toastText=s; toastUntil=System.currentTimeMillis()+1500; invalidate(); }
    private String format(int n) { return String.format(Locale.US,"%,d",n); }

    private void newGame(boolean daily) {
        dailyMode=daily; sessionSeed=daily?dailySeed():System.currentTimeMillis(); random.setSeed(sessionSeed);
        board=new int[N][N]; score=0; combo=0; clears=0; roundIndex=0; lastLines=0; selected=-1; dragging=false;
        clearFlashAt=0L;
        for(int i=0;i<N;i++) java.util.Arrays.fill(clearFlash[i],false);
        used=new boolean[]{false,false,false}; generateTray(); screen=1; hasSavedGame=true; saveNow(); invalidate();
    }
    private long dailySeed() {
        String date=new SimpleDateFormat("yyyyMMdd",Locale.US).format(new Date());
        try { return Long.parseLong(date); } catch(Exception e) { return 20261113L; }
    }

    private void generateTray() {
        random.setSeed(sessionSeed + (long)roundIndex * 104729L);
        roundIndex++;
        for(int i=0;i<3;i++) {
            tray[i]=random.nextInt(SHAPES.length);
            trayColors[i]=random.nextInt(COLORS.length);
            used[i]=false;
        }
    }

    private boolean canPlace(int shape,int row,int col) {
        if(shape<0||shape>=SHAPES.length) return false;
        for(int[] a:SHAPES[shape]) {
            int rr=row+a[0], cc=col+a[1];
            if(rr<0||rr>=N||cc<0||cc>=N||board[rr][cc]!=0) return false;
        }
        return true;
    }
    private boolean hasAnyPlacement(int shape) {
        for(int row=0;row<N;row++) for(int col=0;col<N;col++) if(canPlace(shape,row,col)) return true;
        return false;
    }
    private int[] placementFromPoint(int shape,float x,float y) {
        int[][] cells=SHAPES[shape]; int minR=9,maxR=-1,minC=9,maxC=-1;
        for(int[] a:cells){minR=Math.min(minR,a[0]);maxR=Math.max(maxR,a[0]);minC=Math.min(minC,a[1]);maxC=Math.max(maxC,a[1]);}
        float step=cell+boardGap;
        float gridC=(x-boardX)/step-(minC+maxC)/2f;
        float gridR=(y-boardY)/step-(minR+maxR)/2f;
        return new int[]{Math.round(gridR),Math.round(gridC)};
    }
    private boolean isInsideBoard(float x,float y) { return x>=boardX-25&&x<=boardX+boardSize+25&&y>=boardY-25&&y<=boardY+boardSize+25; }

    private void placePiece(int slot,int row,int col) {
        if(slot<0||slot>2||used[slot]) return;
        int shape=tray[slot]; if(!canPlace(shape,row,col)){toast("That shape does not fit there");return;}
        int color=COLORS[trayColors[slot]%COLORS.length];
        for(int[] a:SHAPES[shape]) board[row+a[0]][col+a[1]]=color;
        used[slot]=true; selected=-1; dragging=false;
        clearCompleteLines();
        clears++;
        if(dailyMode) { if(score>dailyBest){dailyBest=score;prefs.edit().putInt("daily_best",dailyBest).putString("daily_date",new SimpleDateFormat("yyyyMMdd",Locale.US).format(new Date())).apply();} }
        else if(score>best){best=score;prefs.edit().putInt("best",best).apply();}
        boolean anyMove=false, allUsed=true;
        for(int i=0;i<3;i++) if(!used[i]) { allUsed=false; if(hasAnyPlacement(tray[i])) anyMove=true; }
        if(allUsed) {
            generateTray();
            anyMove=false; for(int i=0;i<3;i++) if(hasAnyPlacement(tray[i])) anyMove=true;
        } else if(!anyMove) {
            screen=4; hasSavedGame=false; saveNow(); feedback(); invalidate(); return;
        }
        if(!anyMove) { screen=4; hasSavedGame=false; }
        saveNow(); feedback(); invalidate();
    }

    private void clearCompleteLines() {
        boolean[] rows=new boolean[N], cols=new boolean[N];
        int rowCount=0,colCount=0;
        for(int i=0;i<N;i++) {
            boolean full=true;
            for(int j=0;j<N;j++) if(board[i][j]==0){full=false;break;}
            rows[i]=full;
            if(full) rowCount++;
        }
        for(int j=0;j<N;j++) {
            boolean full=true;
            for(int i=0;i<N;i++) if(board[i][j]==0){full=false;break;}
            cols[j]=full;
            if(full) colCount++;
        }

        int totalLines=rowCount+colCount;
        if(totalLines==0) {
            combo=0;
            lastLines=0;
            return;
        }

        for(int i=0;i<N;i++) java.util.Arrays.fill(clearFlash[i],false);
        int clearedCells=0;
        for(int i=0;i<N;i++) for(int j=0;j<N;j++) if(rows[i]||cols[j]) {
            clearFlash[i][j]=true;
            clearedCells++;
            board[i][j]=0;
        }

        combo++;
        lastLines=totalLines;
        int points=clearedCells*10*combo;
        score+=points;
        clearFlashAt=android.os.SystemClock.uptimeMillis();
        toast((totalLines>1?"MULTI CLEAR":"LINE CLEAR")+"  +"+format(points)+(combo>1?"  COMBO ×"+combo:""));
        postInvalidateDelayed(16);
    }

    private void feedback() {
        if(hapticsOn) performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY);
        if(soundOn && Build.VERSION.SDK_INT>=23) {
            // A tiny built-in click feedback; no sound files or network are used.
            playTone();
        }
    }
    private void playTone() {
        try {
            android.media.ToneGenerator tg=new android.media.ToneGenerator(android.media.AudioManager.STREAM_MUSIC,35);
            tg.startTone(android.media.ToneGenerator.TONE_PROP_ACK,65);
            postDelayed(tg::release,120);
        } catch(Exception ignored) { }
    }

    void saveNow() {
        if(prefs==null)return;
        StringBuilder b=new StringBuilder();
        for(int i=0;i<N;i++)for(int j=0;j<N;j++)b.append(board[i][j]).append(',');
        StringBuilder t=new StringBuilder(), co=new StringBuilder(), u=new StringBuilder();
        for(int i=0;i<3;i++){t.append(tray[i]).append(',');co.append(trayColors[i]).append(',');u.append(used[i]?1:0).append(',');}
        boolean inProgress=hasSavedGame && screen!=4;
        prefs.edit().putString("board",b.toString()).putString("tray",t.toString()).putString("tray_colors",co.toString())
            .putString("used",u.toString()) .putInt("score",score).putInt("combo",combo).putInt("round_index",roundIndex).putLong("seed",sessionSeed)
            .putBoolean("daily",dailyMode).putBoolean("has_game",inProgress).putBoolean("sound",soundOn)
            .putBoolean("haptics",hapticsOn).putBoolean("light",lightTheme).apply();
        hasSavedGame=inProgress;
    }

    private void loadGame() {
        hasSavedGame=prefs.getBoolean("has_game",false);
        if(!hasSavedGame)return;
        try {
            String[] cells=prefs.getString("board","").split(","); int k=0;
            for(int i=0;i<N;i++)for(int j=0;j<N;j++)board[i][j]=Integer.parseInt(cells[k++]);
            String[] ts=prefs.getString("tray","").split(","), cs=prefs.getString("tray_colors","").split(","), us=prefs.getString("used","").split(",");
            for(int i=0;i<3;i++){tray[i]=Integer.parseInt(ts[i]);trayColors[i]=Integer.parseInt(cs[i]);used[i]=Integer.parseInt(us[i])==1;}
            score=prefs.getInt("score",0);combo=prefs.getInt("combo",0);roundIndex=prefs.getInt("round_index",1);sessionSeed=prefs.getLong("seed",System.currentTimeMillis());dailyMode=prefs.getBoolean("daily",false);
        } catch(Exception e) { board=new int[N][N];hasSavedGame=false; prefs.edit().putBoolean("has_game",false).apply(); }
    }

    private float lx(float x){return x/unit;}
    private float ly(float y){return y/unit;}

    @Override public boolean onTouchEvent(MotionEvent e) {
        float x=lx(e.getX()), y=ly(e.getY());
        switch(e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downX=x;downY=y;pointerX=x;pointerY=y;moved=false;
                if(screen==1 && y>=trayY-8 && y<=trayY+104) {
                    int slot=(int)((x-34)/124f);
                    if(slot>=0&&slot<3&&!used[slot]){selected=slot;dragging=true;}
                }
                invalidate(); return true;
            case MotionEvent.ACTION_MOVE:
                pointerX=x;pointerY=y;
                if(dragging && Math.hypot(x-downX,y-downY)>5) { moved=true; invalidate(); }
                return true;
            case MotionEvent.ACTION_UP:
                pointerX=x;pointerY=y;
                handleTapOrDrop(x,y);
                invalidate();return true;
            case MotionEvent.ACTION_CANCEL:
                dragging=false;invalidate();return true;
        }
        return true;
    }

    private void handleTapOrDrop(float x,float y) {
        if(screen==0) {
            if(y>355&&y<435){newGame(false);return;}
            if(y>438&&y<510){newGame(true);return;}
            if(hasSavedGame&&y>510&&y<580){screen=1;invalidate();return;}
            float b=hasSavedGame?595:535;
            if(y>b&&y<b+54){if(x<206)screen=3;else screen=2;return;}
            return;
        }
        if(screen==2){
            if(y>logicalH-195&&y<logicalH-130){screen=5;return;}
            if(y>logicalH-115){screen=0;return;}
            for(int i=0;i<3;i++){float yy=176+i*84;if(y>yy&&y<yy+64){if(i==0)soundOn=!soundOn;else if(i==1)hapticsOn=!hapticsOn;else lightTheme=!lightTheme;saveNow();return;}}
            return;
        }
        if(screen==3){if(y>logicalH-145){screen=0;return;}return;}
        if(screen==5){if(y>logicalH-145){screen=2;return;}return;}
        if(screen==4){
            float top=logicalH*0.28f;
            if(y>top+245&&y<top+322){newGame(dailyMode);return;}
            if(y>top+320&&y<top+380){if(shareCallback!=null)shareCallback.share(score);return;}
            if(y>top+378){screen=0;saveNow();return;}
            return;
        }
        if(screen==1) {
            if(y<82&&x<76){screen=0;saveNow();selected=-1;dragging=false;return;}
            if(y<84&&x>335){newGame(dailyMode);return;}
            if(dragging&&selected>=0) {
                if(moved && isInsideBoard(x,y-64f)){int[] pos=placementFromPoint(tray[selected],x,y-64f);placePiece(selected,pos[0],pos[1]);}
                else {dragging=false;if(moved)toast("Move the shape onto the board");}
                moved=false;
                return;
            }
            if(selected>=0 && isInsideBoard(x,y)) {int[] pos=placementFromPoint(tray[selected],x,y);placePiece(selected,pos[0],pos[1]);return;}
            if(y>=trayY&&y<=trayY+96){int slot=(int)((x-34)/124f);if(slot>=0&&slot<3&&!used[slot]){selected=slot;dragging=false;}return;}
        }
    }

    public boolean handleBack() {
        if(screen==1){screen=0;selected=-1;dragging=false;saveNow();invalidate();return true;}
        if(screen==5){screen=2;invalidate();return true;}
        if(screen==2||screen==3||screen==4){screen=0;invalidate();return true;}
        return false;
    }
}
