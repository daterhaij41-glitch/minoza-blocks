# تحديث المستودع إلى MINOZA BLOCKS 0.3.0

1. ارفع `Minoza-Blocks-Android-v0.3.0.zip` إلى جذر مستودع `minoza-blocks` باستخدام Add file → Upload files ثم Commit changes.
2. افتح `.github/workflows/build.yml` في المستودع واضغط Edit.
3. استبدل محتوى الملف كاملاً بمحتوى ملف `build.yml` المرفق مع هذه الحزمة، ثم Commit changes.
4. افتح Actions. سيبدأ سير العمل الجديد تلقائياً لأن الملف المضغوط وسير العمل أصبحا موجودين.
5. بعد نجاح Build Minoza Blocks APK 0.3.0، افتح العملية وانزل إلى Artifacts.
6. نزّل `Minoza-Blocks-APK-0.3.0.zip`، واستخرج منه `app-debug.apk`، ثم ثبّته.

قد ترى عملية قديمة بسبب الرفع الأول للملف؛ اعتمد فقط على العملية التي تحمل اسم Build Minoza Blocks APK 0.3.0 بعد تحديث build.yml.

هذا APK تجريبي Debug. لا تنشره على Google Play قبل إنشاء توقيع Release واختبار اللعبة وسياسة الخصوصية على جهاز حقيقي.
