package com.minoza.game;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.View;
import android.media.AudioManager;
import android.media.ToneGenerator;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Random;

/**
 * MINOZA BLOCKS 0.3.0 — fully offline 8x8 fixed-orientation block puzzle.
 * All graphics are drawn natively; no network, ads, analytics or third-party assets.
 */
public final class GameView extends View {
    interface ShareCallback { void share(int score); }

    private static final int N = 8;
    private static final int[] COLORS = {
            0xFF54E0C1, 0xFF68A8FF, 0xFFFFB866, 0xFFB99AFF,
            0xFFFF789B, 0xFF91D86B, 0xFFFFD65E, 0xFF55C7E8
    };
    // Each shape is a fixed set of row/column offsets. Rotation is intentionally disabled.
    private static final int[][][] SHAPES = {
            {{0,0}},
            {{0,0},{0,1}}, {{0,0},{1,0}},
            {{0,0},{0,1},{0,2}}, {{0,0},{1,0},{2,0}},
            {{0,0},{1,0},{1,1}}, {{0,0},{0,1},{1,0}},
            {{0,0},{0,1},{1,1}}, {{0,1},{1,0},{1,1}},
            {{0,0},{0,1},{1,0},{1,1}},
            {{0,0},{0,1},{0,2},{0,3}}, {{0,0},{1,0},{2,0},{3,0}},
            {{0,0},{1,0},{2,0},{2,1}}, {{1,0},{1,1},{1,2},{0,2}},
            {{0,0},{0,1},{1,1},{2,1}}, {{0,1},{1,0},{1,1},{2,0}},
            {{0,0},{0,1},{1,1},{1,2}}, {{0,1},{0,2},{1,0},{1,1}},
            {{0,0},{0,1},{0,2},{0,3},{0,4}}, {{0,0},{1,0},{2,0},{3,0},{4,0}},
            {{0,0},{0,1},{0,2},{1,0},{2,0}}, {{0,0},{0,1},{0,2},{1,1},{2,1}},
            {{0,0},{0,1},{0,2},{1,1},{2,1}}, {{0,1},{1,0},{1,1},{1,2},{2,1}}
    };

    private final ShareCallback shareCallback;
    private final SharedPreferences prefs;
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();
    private final Random random = new Random();

    private final int[][] board = new int[N][N];
    private final int[] tray = new int[3];
    private final int[] trayColors = new int[3];
    private final boolean[] used = new boolean[3];
    private final boolean[][] flashCells = new boolean[N][N];

    private int score, best, combo, roundIndex;
    private int screen = 0; // 0 home, 1 game, 2 settings, 3 help, 4 game-over, 5 paused
    private boolean hasSavedGame, soundOn = true, hapticsOn = true;
    private boolean dailyMode, dragging, moved;
    private int selected = -1;
    private float pointerX, pointerY, downX, downY;
    private float unit = 1f, logicalH = 850f;
    private float boardX, boardY, boardSize, cell, gap, trayY;
    private long sessionSeed = System.currentTimeMillis();
    private long flashStart, toastUntil;
    private String toastText = "";
    private float lastTouchX, lastTouchY;

    private static final int BG_TOP = 0xFF111A2D;
    private static final int BG_BOTTOM = 0xFF080D19;
    private static final int PANEL = 0xFF18253A;
    private static final int PANEL_LIGHT = 0xFF21324B;
    private static final int TEXT = 0xFFF4F7FF;
    private static final int MUTED = 0xFF91A3BD;
    private static final int MINT = 0xFF61E5C4;
    private static final int GOLD = 0xFFFFD56A;
    private static final int CORAL = 0xFFFF789B;

    public GameView(Context context, ShareCallback callback) {
        super(context);
        shareCallback = callback;
        prefs = context.getSharedPreferences("minoza_save_v3", Context.MODE_PRIVATE);
        best = prefs.getInt("best", 0);
        soundOn = prefs.getBoolean("sound", true);
        hapticsOn = prefs.getBoolean("haptics", true);
        setLayerType(View.LAYER_TYPE_HARDWARE, null);
        setFocusable(true);
        loadGame();
    }

    @Override protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        unit = Math.max(0.1f, w / 412f);
        logicalH = h / unit;
        layoutGame();
    }

    private void layoutGame() {
        boardSize = Math.min(376f, logicalH * 0.43f);
        gap = 4f;
        cell = (boardSize - 7f * gap) / 8f;
        boardX = (412f - boardSize) / 2f;
        boardY = Math.max(206f, Math.min(246f, logicalH - boardSize - 292f));
        trayY = Math.max(boardY + boardSize + 65f, logicalH - 164f);
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        layoutGame();
        canvas.save();
        canvas.scale(unit, unit);
        drawBackground(canvas);
        switch (screen) {
            case 0: drawHome(canvas); break;
            case 1: drawGame(canvas); break;
            case 2: drawSettings(canvas); break;
            case 3: drawHelp(canvas); break;
            case 4: drawGameOver(canvas); break;
            case 5: drawPaused(canvas); break;
        }
        if (!toastText.isEmpty() && SystemClock.uptimeMillis() < toastUntil) {
            drawToast(canvas);
            postInvalidateDelayed(45);
        }
        canvas.restore();
        if (!toastText.isEmpty() && SystemClock.uptimeMillis() >= toastUntil) toastText = "";
    }

    private void drawBackground(Canvas c) {
        paint.setShader(new LinearGradient(0, 0, 412, logicalH, BG_TOP, BG_BOTTOM, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, 412, logicalH, paint);
        paint.setShader(new RadialGradient(355, 95, 205, new int[]{0x263D91B8, 0x003D91B8}, null, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, 412, 330, paint);
        paint.setShader(new RadialGradient(34, logicalH - 80, 180, new int[]{0x1833B99A, 0x0033B99A}, null, Shader.TileMode.CLAMP));
        c.drawRect(0, logicalH - 240, 180, logicalH, paint);
        paint.setShader(null);
        // Delicate background grid gives the interface depth without competing with the board.
        paint.setColor(0x0B9DB5D1);
        paint.setStrokeWidth(0.7f);
        for (int x = 18; x < 412; x += 28) c.drawLine(x, 0, x, logicalH, paint);
        for (int y = 12; y < logicalH; y += 28) c.drawLine(0, y, 412, y, paint);
    }

    private void txt(Canvas c, String s, float x, float y, float size, int color, boolean bold, Paint.Align align) {
        paint.setShader(null);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(color);
        paint.setTextSize(size);
        paint.setTypeface(Typeface.create(bold ? "sans-serif" : "sans-serif-medium", bold ? Typeface.BOLD : Typeface.NORMAL));
        paint.setTextAlign(align);
        paint.clearShadowLayer();
        c.drawText(s, x, y, paint);
    }

    private void rr(Canvas c, float x, float y, float w, float h, float radius, int color) {
        paint.setShader(null);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(color);
        paint.clearShadowLayer();
        c.drawRoundRect(x, y, x + w, y + h, radius, radius, paint);
    }

    private void stroke(Canvas c, float x, float y, float w, float h, float r, int color, float width) {
        paint.setShader(null);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(width);
        paint.setColor(color);
        c.drawRoundRect(x, y, x + w, y + h, r, r, paint);
        paint.setStyle(Paint.Style.FILL);
    }

    private void card(Canvas c, float x, float y, float w, float h, float radius) {
        paint.setShader(null);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(PANEL);
        paint.setShadowLayer(14f, 0f, 7f, 0x66000000);
        c.drawRoundRect(x, y + 2, x + w, y + h + 2, radius, radius, paint);
        paint.clearShadowLayer();
        paint.setShader(new LinearGradient(x, y, x + w, y + h, 0xFF1D2D45, 0xFF152238, Shader.TileMode.CLAMP));
        c.drawRoundRect(x, y, x + w, y + h, radius, radius, paint);
        paint.setShader(null);
        stroke(c, x + 0.5f, y + 0.5f, w - 1, h - 1, radius, 0x265B789C, 1f);
    }

    private void pill(Canvas c, String label, float x, float y, float w, int color, int textColor) {
        rr(c, x, y, w, 27, 14, color);
        txt(c, label, x + w / 2f, y + 18, 10, textColor, true, Paint.Align.CENTER);
    }

    private void primaryButton(Canvas c, String label, float x, float y, float w, float h) {
        paint.setShader(new LinearGradient(x, y, x + w, y + h, 0xFF78F0D2, 0xFF38BDA3, Shader.TileMode.CLAMP));
        paint.setShadowLayer(16f, 0, 6, 0x5538D6B4);
        c.drawRoundRect(x, y + 2, x + w, y + h + 2, 19, 19, paint);
        paint.clearShadowLayer();
        paint.setShader(null);
        txt(c, label, x + w / 2f, y + h / 2f + 6, 16, 0xFF09251F, true, Paint.Align.CENTER);
    }

    private void secondaryButton(Canvas c, String label, float x, float y, float w, float h) {
        rr(c, x, y + 2, w, h, 17, 0x66000000);
        rr(c, x, y, w, h, 17, 0xFF24344E);
        stroke(c, x, y, w, h, 17, 0x365C7595, 1f);
        txt(c, label, x + w / 2f, y + h / 2f + 5, 13, TEXT, true, Paint.Align.CENTER);
    }

    private void logoMark(Canvas c, float cx, float cy, float size) {
        float s = size / 4.25f;
        float gapSize = s * 0.13f;
        float left = cx - (2 * s + gapSize) / 2f;
        float top = cy - (2 * s + gapSize) / 2f;
        int[][] shape = {{1,1},{1,0},{1,1}};
        int[] shades = {0xFF73EBD0, 0xFF72ACFF, 0xFFFFC16E, 0xFFB89BFF};
        int k = 0;
        for (int r = 0; r < 2; r++) for (int col = 0; col < 2; col++) {
            if (shape[r][col] == 1) drawTile(c, left + col * (s + gapSize), top + r * (s + gapSize), s, shades[k++], 1f);
        }
    }

    private void drawHome(Canvas c) {
        logoMark(c, 206, 112, 64);
        txt(c, "MINOZA", 206, 198, 40, TEXT, true, Paint.Align.CENTER);
        txt(c, "B L O C K S", 206, 225, 11, MINT, true, Paint.Align.CENTER);
        txt(c, "THE PUZZLE IS YOURS TO SOLVE", 206, 250, 10, MUTED, false, Paint.Align.CENTER);

        card(c, 28, 280, 356, 102, 23);
        txt(c, "PERSONAL BEST", 52, 312, 10, MUTED, true, Paint.Align.LEFT);
        txt(c, format(best), 52, 359, 37, TEXT, true, Paint.Align.LEFT);
        pill(c, "BEST RUN", 278, 316, 82, 0xFF35445D, 0xFFCBD7EA);
        txt(c, "∞", 319, 365, 25, GOLD, true, Paint.Align.CENTER);

        primaryButton(c, hasSavedGame ? "NEW CLASSIC GAME" : "PLAY CLASSIC", 36, 418, 340, 62);
        secondaryButton(c, "DAILY CHALLENGE", 36, 494, 340, 52);
        if (hasSavedGame) secondaryButton(c, "CONTINUE SAVED GAME", 36, 558, 340, 49);

        float bottomY = logicalH - 100;
        secondaryButton(c, "HOW TO PLAY", 36, bottomY, 164, 48);
        secondaryButton(c, "SETTINGS", 212, bottomY, 164, 48);
        txt(c, "NO TIMER   ·   NO GRAVITY   ·   PURE STRATEGY", 206, logicalH - 30, 9, 0xFF72859F, true, Paint.Align.CENTER);
    }

    private void drawGameHeader(Canvas c) {
        logoMark(c, 36, 41, 28);
        txt(c, dailyMode ? "DAILY" : "CLASSIC", 70, 45, 11, TEXT, true, Paint.Align.LEFT);
        txt(c, "8 × 8 PUZZLE", 70, 61, 8, MUTED, false, Paint.Align.LEFT);
        rr(c, 344, 20, 48, 48, 16, 0xFF22324A);
        stroke(c, 344, 20, 48, 48, 16, 0x3C7B99B7, 1f);
        // Pause icon.
        rr(c, 360, 34, 5, 20, 2, MINT);
        rr(c, 370, 34, 5, 20, 2, MINT);

        card(c, 20, 80, 372, 100, 21);
        txt(c, "SCORE", 48, 111, 9, MUTED, true, Paint.Align.LEFT);
        txt(c, format(score), 48, 155, 35, TEXT, true, Paint.Align.LEFT);
        rr(c, 255, 98, 1.2f, 64, 1, 0x3A6F849F);
        txt(c, "BEST", 279, 111, 9, MUTED, true, Paint.Align.LEFT);
        txt(c, format(best), 279, 144, 21, 0xFFFFD777, true, Paint.Align.LEFT);
        if (combo > 0) pill(c, "COMBO ×" + combo, 146, 142, 94, 0xFF28554F, 0xFF8FF5D7);
    }

    private void drawBoard(Canvas c) {
        txt(c, "YOUR BOARD", 28, boardY - 18, 10, MUTED, true, Paint.Align.LEFT);
        txt(c, "FILL A LINE TO CLEAR IT", 384, boardY - 18, 9, 0xFF7488A4, true, Paint.Align.RIGHT);
        card(c, boardX - 10, boardY - 10, boardSize + 20, boardSize + 20, 23);

        boolean[] previewRows = new boolean[N];
        boolean[] previewCols = new boolean[N];
        int previewTop = -1, previewLeft = -1;
        boolean previewValid = false;
        int previewShape = -1;
        if (dragging && selected >= 0 && isInsideBoard(pointerX, pointerY - 66f)) {
            previewShape = tray[selected];
            int[] at = placementFromPoint(previewShape, pointerX, pointerY - 66f);
            previewTop = at[0];
            previewLeft = at[1];
            previewValid = canPlace(previewShape, previewTop, previewLeft);
            if (previewValid) findPreviewLines(previewShape, previewTop, previewLeft, previewRows, previewCols);
        }

        float step = cell + gap;
        for (int r = 0; r < N; r++) for (int col = 0; col < N; col++) {
            float x = boardX + col * step;
            float y = boardY + r * step;
            boolean previewLine = previewValid && (previewRows[r] || previewCols[col]);
            if (previewLine) rr(c, x - 1, y - 1, cell + 2, cell + 2, 9, 0x55FFD36A);
            if (board[r][col] == 0) {
                rr(c, x, y + 1.5f, cell, cell, 8, 0xFF0E192A);
                rr(c, x, y, cell, cell, 8, previewLine ? 0xFF485044 : 0xFF26354C);
                stroke(c, x + 0.5f, y + 0.5f, cell - 1, cell - 1, 8, 0x1F9FB6D3, 0.8f);
            } else {
                drawTile(c, x, y, cell, board[r][col], 1f);
            }
            if (flashCells[r][col]) {
                float progress = (SystemClock.uptimeMillis() - flashStart) / 480f;
                if (progress < 1f) {
                    int alpha = (int)(150 * (1f - progress));
                    rr(c, x, y, cell, cell, 8, Color.argb(alpha, 255, 219, 117));
                    postInvalidateDelayed(16);
                } else flashCells[r][col] = false;
            }
        }

        if (previewShape >= 0) {
            int[][] shape = SHAPES[previewShape];
            int color = previewValid ? COLORS[trayColors[selected] % COLORS.length] : CORAL;
            for (int[] part : shape) {
                int r = previewTop + part[0];
                int col = previewLeft + part[1];
                if (r >= 0 && r < N && col >= 0 && col < N) {
                    float x = boardX + col * step;
                    float y = boardY + r * step;
                    drawTile(c, x, y, cell, color, previewValid ? 0.47f : 0.35f);
                }
            }
            if (previewValid && (anyTrue(previewRows) || anyTrue(previewCols))) {
                pill(c, "LINE CLEAR READY", 139, boardY + boardSize + 17, 134, 0xFF4A3C2A, GOLD);
            }
        }
    }

    private boolean anyTrue(boolean[] values) { for (boolean value : values) if (value) return true; return false; }

    private void findPreviewLines(int shape, int top, int left, boolean[] rows, boolean[] cols) {
        for (int r = 0; r < N; r++) {
            boolean full = true;
            for (int col = 0; col < N; col++) if (!filledAfterPreview(r, col, shape, top, left)) { full = false; break; }
            rows[r] = full;
        }
        for (int col = 0; col < N; col++) {
            boolean full = true;
            for (int r = 0; r < N; r++) if (!filledAfterPreview(r, col, shape, top, left)) { full = false; break; }
            cols[col] = full;
        }
    }

    private boolean filledAfterPreview(int r, int col, int shape, int top, int left) {
        if (board[r][col] != 0) return true;
        for (int[] part : SHAPES[shape]) if (top + part[0] == r && left + part[1] == col) return true;
        return false;
    }

    private void drawTray(Canvas c) {
        txt(c, "NEXT PIECES", 28, trayY - 17, 10, MUTED, true, Paint.Align.LEFT);
        txt(c, "3 SHAPES  ·  NO ROTATION", 384, trayY - 17, 9, 0xFF7488A4, true, Paint.Align.RIGHT);
        float start = 28, slotW = 112, slotH = 94;
        for (int i = 0; i < 3; i++) {
            float x = start + i * 120;
            card(c, x, trayY, slotW, slotH, 18);
            if (used[i]) {
                rr(c, x + 39, trayY + 31, 34, 30, 12, 0xFF234A43);
                txt(c, "✓", x + 56, trayY + 52, 19, MINT, true, Paint.Align.CENTER);
                txt(c, "PLACED", x + 56, trayY + 78, 8, 0xFF6A9A8B, true, Paint.Align.CENTER);
            } else {
                drawShapeMini(c, tray[i], trayColors[i], x + slotW / 2f, trayY + 46, 15.5f, 1f);
            }
            if (selected == i && !used[i]) stroke(c, x - 1, trayY - 1, slotW + 2, slotH + 2, 19, MINT, 2f);
        }
        txt(c, "TAP A PIECE, THEN THE BOARD  ·  OR DRAG IT", 206, logicalH - 27, 9, 0xFF7E91AA, true, Paint.Align.CENTER);
        if (dragging && selected >= 0) drawShapeMini(c, tray[selected], trayColors[selected], pointerX, pointerY - 66f, 24f, 0.94f);
    }

    private void drawGame(Canvas c) {
        drawGameHeader(c);
        drawBoard(c);
        drawTray(c);
    }

    private void drawTile(Canvas c, float x, float y, float size, int color, float alpha) {
        int a = Math.max(0, Math.min(255, (int)(Color.alpha(color) * alpha)));
        int base = Color.argb(a, Color.red(color), Color.green(color), Color.blue(color));
        int dark = Color.argb(a, Math.max(0, Color.red(color) - 45), Math.max(0, Color.green(color) - 45), Math.max(0, Color.blue(color) - 45));
        paint.setShader(null);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.argb((int)(62 * alpha), 0, 0, 0));
        c.drawRoundRect(x, y + 2.4f, x + size, y + size + 2.4f, 8, 8, paint);
        paint.setShader(new LinearGradient(x, y, x + size * 0.25f, y + size, base, dark, Shader.TileMode.CLAMP));
        c.drawRoundRect(x, y, x + size, y + size, 8, 8, paint);
        paint.setShader(null);
        paint.setColor(Color.argb((int)(72 * alpha), 255, 255, 255));
        c.drawRoundRect(x + 2, y + 2, x + size - 2, y + Math.max(4, size * 0.29f), 6, 6, paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(0.85f);
        paint.setColor(Color.argb((int)(95 * alpha), 255, 255, 255));
        c.drawRoundRect(x + 0.6f, y + 0.6f, x + size - 0.6f, y + size - 0.6f, 8, 8, paint);
        paint.setStyle(Paint.Style.FILL);
    }

    private void drawShapeMini(Canvas c, int shapeIndex, int colorIndex, float cx, float cy, float maxCell, float alpha) {
        int[][] shape = SHAPES[shapeIndex];
        int maxRow = 0, maxCol = 0;
        for (int[] part : shape) { maxRow = Math.max(maxRow, part[0]); maxCol = Math.max(maxCol, part[1]); }
        float smallGap = 3f;
        float size = Math.min(maxCell, Math.min(84f / (maxCol + 1), 67f / (maxRow + 1)));
        float w = (maxCol + 1) * size + maxCol * smallGap;
        float h = (maxRow + 1) * size + maxRow * smallGap;
        float left = cx - w / 2f, top = cy - h / 2f;
        int color = COLORS[colorIndex % COLORS.length];
        for (int[] part : shape) drawTile(c, left + part[1] * (size + smallGap), top + part[0] * (size + smallGap), size, color, alpha);
    }

    private void drawSettings(Canvas c) {
        txt(c, "SETTINGS", 206, 104, 29, TEXT, true, Paint.Align.CENTER);
        txt(c, "Your game, your preferences", 206, 130, 12, MUTED, false, Paint.Align.CENTER);
        String[] labels = {"Sound effects", "Vibration"};
        boolean[] values = {soundOn, hapticsOn};
        for (int i = 0; i < labels.length; i++) {
            float y = 190 + i * 86;
            card(c, 28, y, 356, 65, 18);
            txt(c, labels[i], 52, y + 39, 15, TEXT, true, Paint.Align.LEFT);
            pill(c, values[i] ? "ON" : "OFF", 310, y + 18, 54, values[i] ? 0xFF28554F : 0xFF34435A, values[i] ? MINT : MUTED);
        }
        txt(c, "MINOZA BLOCKS  ·  VERSION 0.3.0", 206, logicalH - 170, 10, MUTED, true, Paint.Align.CENTER);
        primaryButton(c, "BACK TO HOME", 36, logicalH - 112, 340, 54);
    }

    private void drawHelp(Canvas c) {
        txt(c, "HOW TO PLAY", 206, 88, 28, TEXT, true, Paint.Align.CENTER);
        txt(c, "Simple rules. Deep strategy.", 206, 116, 12, MUTED, false, Paint.Align.CENTER);
        String[][] items = {
                {"01  PLACE", "Drag one of the three shapes onto empty cells."},
                {"02  CLEAR", "Complete a full row or column to clear it."},
                {"03  COMBO", "Clear on consecutive moves to build a streak."},
                {"04  SURVIVE", "No rotations, no gravity and no timer."}
        };
        for (int i = 0; i < items.length; i++) {
            float y = 160 + i * 112;
            card(c, 28, y, 356, 91, 18);
            txt(c, items[i][0], 50, y + 33, 12, MINT, true, Paint.Align.LEFT);
            txt(c, items[i][1], 50, y + 61, 11, TEXT, false, Paint.Align.LEFT);
        }
        txt(c, "10 points per cleared cell. Intersections count once.", 206, logicalH - 145, 10, MUTED, false, Paint.Align.CENTER);
        primaryButton(c, "GOT IT", 36, logicalH - 105, 340, 52);
    }

    private void drawGameOver(Canvas c) {
        drawGame(c);
        rr(c, 0, 0, 412, logicalH, 0, 0xB9080D19);
        float top = Math.max(220, logicalH * 0.28f);
        card(c, 28, top, 356, 390, 27);
        pill(c, "RUN COMPLETE", 142, top + 25, 128, 0xFF4A3C2A, GOLD);
        txt(c, "NO MORE MOVES", 206, top + 91, 24, TEXT, true, Paint.Align.CENTER);
        txt(c, "None of the remaining pieces can fit.", 206, top + 119, 11, MUTED, false, Paint.Align.CENTER);
        txt(c, "YOUR SCORE", 206, top + 170, 10, MUTED, true, Paint.Align.CENTER);
        txt(c, format(score), 206, top + 222, 43, MINT, true, Paint.Align.CENTER);
        txt(c, "PERSONAL BEST  " + format(best), 206, top + 250, 11, GOLD, true, Paint.Align.CENTER);
        primaryButton(c, "PLAY AGAIN", 52, top + 280, 308, 52);
        secondaryButton(c, "SHARE SCORE", 52, top + 342, 308, 45);
    }

    private void drawPaused(Canvas c) {
        drawGame(c);
        rr(c, 0, 0, 412, logicalH, 0, 0xB9080D19);
        float top = Math.max(224, logicalH * 0.29f);
        card(c, 34, top, 344, 330, 26);
        txt(c, "PAUSED", 206, top + 67, 28, TEXT, true, Paint.Align.CENTER);
        txt(c, "Your board is saved on this device.", 206, top + 94, 11, MUTED, false, Paint.Align.CENTER);
        primaryButton(c, "RESUME", 58, top + 126, 296, 52);
        secondaryButton(c, "RESTART GAME", 58, top + 190, 296, 48);
        secondaryButton(c, "HOME", 58, top + 250, 296, 45);
    }

    private void drawToast(Canvas c) {
        float w = Math.min(330, Math.max(190, toastText.length() * 7.2f));
        rr(c, 206 - w / 2, logicalH - 88, w, 38, 19, 0xEE25364F);
        stroke(c, 206 - w / 2, logicalH - 88, w, 38, 19, 0x446E90B1, 1f);
        txt(c, toastText, 206, logicalH - 64, 11, TEXT, true, Paint.Align.CENTER);
    }

    private void toast(String message) {
        toastText = message;
        toastUntil = SystemClock.uptimeMillis() + 1700;
        invalidate();
    }

    private String format(int value) { return String.format(Locale.US, "%,d", value); }

    private void newGame(boolean daily) {
        dailyMode = daily;
        sessionSeed = daily ? dailySeed() : System.currentTimeMillis();
        random.setSeed(sessionSeed);
        for (int r = 0; r < N; r++) java.util.Arrays.fill(board[r], 0);
        score = 0;
        combo = 0;
        roundIndex = 0;
        selected = -1;
        dragging = false;
        flashStart = 0;
        for (int r = 0; r < N; r++) java.util.Arrays.fill(flashCells[r], false);
        generateTray();
        screen = 1;
        hasSavedGame = true;
        saveNow();
        invalidate();
    }

    private long dailySeed() {
        String date = new SimpleDateFormat("yyyyMMdd", Locale.US).format(new Date());
        try { return Long.parseLong(date); } catch (Exception ignored) { return 20261113L; }
    }

    private void generateTray() {
        random.setSeed(sessionSeed + (long) roundIndex * 104729L);
        roundIndex++;
        for (int i = 0; i < 3; i++) {
            tray[i] = random.nextInt(SHAPES.length);
            trayColors[i] = random.nextInt(COLORS.length);
            used[i] = false;
        }
    }

    private boolean canPlace(int shape, int row, int col) {
        if (shape < 0 || shape >= SHAPES.length) return false;
        for (int[] part : SHAPES[shape]) {
            int r = row + part[0], c = col + part[1];
            if (r < 0 || r >= N || c < 0 || c >= N || board[r][c] != 0) return false;
        }
        return true;
    }

    private boolean hasAnyPlacement(int shape) {
        for (int r = 0; r < N; r++) for (int c = 0; c < N; c++) if (canPlace(shape, r, c)) return true;
        return false;
    }

    private boolean hasMoveAmongRemaining() {
        for (int i = 0; i < 3; i++) if (!used[i] && hasAnyPlacement(tray[i])) return true;
        return false;
    }

    private int[] placementFromPoint(int shape, float x, float y) {
        int maxRow = 0, maxCol = 0;
        for (int[] part : SHAPES[shape]) { maxRow = Math.max(maxRow, part[0]); maxCol = Math.max(maxCol, part[1]); }
        float step = cell + gap;
        float shapeW = (maxCol + 1) * cell + maxCol * gap;
        float shapeH = (maxRow + 1) * cell + maxRow * gap;
        float left = x - shapeW / 2f;
        float top = y - shapeH / 2f;
        return new int[]{Math.round((top - boardY) / step), Math.round((left - boardX) / step)};
    }

    private boolean isInsideBoard(float x, float y) {
        return x >= boardX - 18 && x <= boardX + boardSize + 18 && y >= boardY - 18 && y <= boardY + boardSize + 18;
    }

    private void placePiece(int slot, int row, int col) {
        if (slot < 0 || slot >= 3 || used[slot]) return;
        int shape = tray[slot];
        if (!canPlace(shape, row, col)) {
            dragging = false;
            toast("That position does not fit");
            feedback(false);
            return;
        }

        int color = COLORS[trayColors[slot] % COLORS.length];
        for (int[] part : SHAPES[shape]) board[row + part[0]][col + part[1]] = color;
        used[slot] = true;
        selected = -1;
        dragging = false;

        int points = clearCompleteLines();
        if (points == 0) combo = 0;
        score += points;
        if (score > best) {
            best = score;
            prefs.edit().putInt("best", best).apply();
        }

        if (!hasMoveAmongRemaining()) {
            boolean allUsed = true;
            for (boolean value : used) if (!value) { allUsed = false; break; }
            if (allUsed) {
                generateTray();
                if (!hasMoveAmongRemaining()) finishGame();
                else saveNow();
            } else {
                finishGame();
            }
        } else {
            saveNow();
        }

        feedback(points > 0);
        invalidate();
    }

    /** Returns points earned. All full rows and columns are collected before anything is cleared. */
    private int clearCompleteLines() {
        boolean[] rows = new boolean[N], cols = new boolean[N];
        int rowCount = 0, colCount = 0;
        for (int r = 0; r < N; r++) {
            boolean full = true;
            for (int c = 0; c < N; c++) if (board[r][c] == 0) { full = false; break; }
            rows[r] = full;
            if (full) rowCount++;
        }
        for (int c = 0; c < N; c++) {
            boolean full = true;
            for (int r = 0; r < N; r++) if (board[r][c] == 0) { full = false; break; }
            cols[c] = full;
            if (full) colCount++;
        }
        if (rowCount + colCount == 0) return 0;

        for (int r = 0; r < N; r++) java.util.Arrays.fill(flashCells[r], false);
        int clearedCells = 0;
        for (int r = 0; r < N; r++) for (int c = 0; c < N; c++) {
            if (rows[r] || cols[c]) {
                flashCells[r][c] = true;
                board[r][c] = 0;
                clearedCells++;
            }
        }
        combo++;
        flashStart = SystemClock.uptimeMillis();
        int basePoints = clearedCells * 10;
        int comboBonus = combo > 1 ? (combo - 1) * 50 : 0;
        int total = basePoints + comboBonus;
        toast("+" + format(total) + (combo > 1 ? "   COMBO ×" + combo : "   LINE CLEAR"));
        return total;
    }

    private void finishGame() {
        screen = 4;
        hasSavedGame = false;
        prefs.edit().putBoolean("has_game", false).apply();
        saveNow();
    }

    private void feedback(boolean cleared) {
        if (hapticsOn) performHapticFeedback(cleared ? android.view.HapticFeedbackConstants.LONG_PRESS : android.view.HapticFeedbackConstants.KEYBOARD_TAP);
        if (soundOn) {
            try {
                final ToneGenerator tone = new ToneGenerator(AudioManager.STREAM_MUSIC, 34);
                tone.startTone(cleared ? ToneGenerator.TONE_PROP_ACK : ToneGenerator.TONE_PROP_BEEP, cleared ? 110 : 55);
                postDelayed(tone::release, 180);
            } catch (Exception ignored) { }
        }
    }

    void saveNow() {
        StringBuilder cells = new StringBuilder();
        for (int r = 0; r < N; r++) for (int c = 0; c < N; c++) cells.append(board[r][c]).append(',');
        StringBuilder t = new StringBuilder(), tc = new StringBuilder(), u = new StringBuilder();
        for (int i = 0; i < 3; i++) { t.append(tray[i]).append(','); tc.append(trayColors[i]).append(','); u.append(used[i] ? 1 : 0).append(','); }
        boolean inProgress = hasSavedGame && screen != 4;
        prefs.edit().putString("board", cells.toString()).putString("tray", t.toString())
                .putString("tray_colors", tc.toString()).putString("used", u.toString())
                .putInt("score", score).putInt("combo", combo).putInt("round_index", roundIndex)
                .putLong("seed", sessionSeed).putBoolean("daily", dailyMode)
                .putBoolean("has_game", inProgress).putBoolean("sound", soundOn)
                .putBoolean("haptics", hapticsOn).apply();
        hasSavedGame = inProgress;
    }

    private void loadGame() {
        hasSavedGame = prefs.getBoolean("has_game", false);
        if (!hasSavedGame) return;
        try {
            String[] cells = prefs.getString("board", "").split(",");
            if (cells.length < N * N) throw new IllegalStateException("Bad saved board");
            int k = 0;
            for (int r = 0; r < N; r++) for (int c = 0; c < N; c++) board[r][c] = Integer.parseInt(cells[k++]);
            String[] t = prefs.getString("tray", "").split(",");
            String[] tc = prefs.getString("tray_colors", "").split(",");
            String[] u = prefs.getString("used", "").split(",");
            for (int i = 0; i < 3; i++) {
                tray[i] = Integer.parseInt(t[i]); trayColors[i] = Integer.parseInt(tc[i]); used[i] = Integer.parseInt(u[i]) == 1;
                if (tray[i] < 0 || tray[i] >= SHAPES.length) throw new IllegalStateException("Bad saved shape");
            }
            score = prefs.getInt("score", 0);
            combo = prefs.getInt("combo", 0);
            roundIndex = prefs.getInt("round_index", 1);
            sessionSeed = prefs.getLong("seed", System.currentTimeMillis());
            dailyMode = prefs.getBoolean("daily", false);
        } catch (Exception error) {
            for (int r = 0; r < N; r++) java.util.Arrays.fill(board[r], 0);
            hasSavedGame = false;
            prefs.edit().putBoolean("has_game", false).apply();
        }
    }

    private void tapHome(float x, float y) {
        if (y >= 418 && y <= 480) { newGame(false); return; }
        if (y >= 494 && y <= 546) { newGame(true); return; }
        if (hasSavedGame && y >= 558 && y <= 607) { screen = 1; saveNow(); return; }
        float bottom = logicalH - 100;
        if (y >= bottom && y <= bottom + 50) {
            if (x < 206) screen = 3; else screen = 2;
        }
    }

    private void tapGame(float x, float y) {
        if (y < 76 && x < 94) { screen = 0; selected = -1; dragging = false; saveNow(); return; }
        if (y < 76 && x > 328) { screen = 5; selected = -1; dragging = false; saveNow(); return; }

        if (dragging && selected >= 0) {
            if (moved && isInsideBoard(x, y - 66f)) {
                int[] at = placementFromPoint(tray[selected], x, y - 66f);
                placePiece(selected, at[0], at[1]);
            } else {
                dragging = false;
                if (moved) toast("Drop the piece on the board");
            }
            moved = false;
            return;
        }
        if (selected >= 0 && isInsideBoard(x, y)) {
            int[] at = placementFromPoint(tray[selected], x, y);
            placePiece(selected, at[0], at[1]);
            return;
        }
        int slot = slotAt(x, y);
        if (slot >= 0 && !used[slot]) { selected = slot; dragging = false; }
    }

    private int slotAt(float x, float y) {
        if (y < trayY - 6 || y > trayY + 100) return -1;
        for (int i = 0; i < 3; i++) {
            float left = 28 + i * 120;
            if (x >= left && x <= left + 112) return i;
        }
        return -1;
    }

    private void tapGameOver(float x, float y) {
        float top = Math.max(220, logicalH * 0.28f);
        if (y >= top + 275 && y <= top + 340) newGame(dailyMode);
        else if (y >= top + 340 && y <= top + 400) {
            if (shareCallback != null) shareCallback.share(score);
        }
    }

    private void tapPaused(float x, float y) {
        float top = Math.max(224, logicalH * 0.29f);
        if (y >= top + 120 && y <= top + 184) { screen = 1; return; }
        if (y >= top + 184 && y <= top + 244) { newGame(dailyMode); return; }
        if (y >= top + 244 && y <= top + 310) { screen = 0; selected = -1; dragging = false; saveNow(); }
    }

    @Override public boolean onTouchEvent(MotionEvent event) {
        float x = event.getX() / unit;
        float y = event.getY() / unit;
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downX = x; downY = y; pointerX = x; pointerY = y; moved = false;
                if (screen == 1) {
                    int slot = slotAt(x, y);
                    if (slot >= 0 && !used[slot]) { selected = slot; dragging = true; }
                }
                invalidate();
                return true;
            case MotionEvent.ACTION_MOVE:
                pointerX = x; pointerY = y;
                if (dragging && Math.hypot(x - downX, y - downY) > 5) moved = true;
                invalidate();
                return true;
            case MotionEvent.ACTION_UP:
                pointerX = x; pointerY = y;
                switch (screen) {
                    case 0: tapHome(x, y); break;
                    case 1: tapGame(x, y); break;
                    case 2:
                        if (y >= logicalH - 118) screen = 0;
                        else if (y >= 190 && y <= 255) { soundOn = !soundOn; saveNow(); }
                        else if (y >= 276 && y <= 345) { hapticsOn = !hapticsOn; saveNow(); }
                        break;
                    case 3: if (y >= logicalH - 112) screen = 0; break;
                    case 4: tapGameOver(x, y); break;
                    case 5: tapPaused(x, y); break;
                }
                invalidate();
                return true;
            case MotionEvent.ACTION_CANCEL:
                dragging = false;
                invalidate();
                return true;
            default: return true;
        }
    }

    public boolean handleBack() {
        if (screen == 1) { screen = 5; selected = -1; dragging = false; saveNow(); invalidate(); return true; }
        if (screen == 5) { screen = 1; invalidate(); return true; }
        if (screen == 2 || screen == 3 || screen == 4) { screen = 0; invalidate(); return true; }
        return false;
    }
}
