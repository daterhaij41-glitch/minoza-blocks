# MINOZA BLOCKS 0.3.0

An original, offline Android block puzzle built with native Java and Canvas.

## Core rules
- 8×8 board.
- Three fixed-orientation pieces per batch; no rotation or flipping.
- No gravity and no timer.
- Completed rows and columns clear together after every placement.
- Intersections count once; base score is 10 points per cleared cell.
- Combo streak bonus is additive and is reset by a move that clears no line.
- Game over when none of the unused pieces in the current three-piece batch can legally fit.

## Technical
- Native Android Activity + custom Canvas View.
- No third-party dependencies, ads, analytics, network calls or account requirement.
- Local persistence with SharedPreferences.
- minSdk 23, compileSdk 36, Java 17, Gradle 8.13.

## Build
Use GitHub Actions to build `:app:assembleDebug`; see `START_HERE_AR.md` for the Arabic upload notes.
