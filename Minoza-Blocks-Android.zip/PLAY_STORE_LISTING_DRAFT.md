# Google Play listing draft

**Title:** Minoza Blocks  
**Short description:** Place smart. Clear lines. Chase your best score.

**Full description:**

Relax your mind and keep your strategy sharp in Minoza Blocks, an original block-placement puzzle designed for quick breaks and longer high-score runs.

Drag colorful shapes onto the 8×8 board. Complete full rows and columns to clear space, build consecutive-clear combos, and keep the board alive for as long as you can. Every shape matters, so think ahead and make each placement count.

**FEATURES**
- Easy-to-learn 8×8 block puzzle gameplay
- Three shapes at a time: place them in the order that works best
- Clear rows and columns to earn points
- Consecutive clears add combo bonuses
- Classic endless score-chasing mode
- Daily challenge with a date-based seed
- Save your current game and continue later
- Personal best stored on your device
- Dark and light appearances
- Optional sound and haptic feedback
- Play offline — no account required in this version

A simple puzzle to start. A smarter move to beat your record.

**Before submission:** confirm title availability, add actual screenshots from a tested release build, add a support email, host `PRIVACY_POLICY.html` at a public HTTPS URL, and complete Play Console content rating and Data safety declarations.
