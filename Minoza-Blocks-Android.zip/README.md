# Minoza Blocks — Android prototype

An original, offline-first 8×8 block-placement puzzle built with native Android Java. It is inspired by the broad genre mechanics of placing shapes and clearing complete rows/columns; it does not use Block Blast branding, artwork, sounds, or source code.

## Included in this first build

- Native Android app, portrait orientation, no third-party dependencies.
- 8×8 board, 3-piece tray, drag/drop and tap-to-place controls.
- Line and column clears, score, personal best, consecutive-clear combo bonus.
- Classic and date-seeded daily challenge modes.
- Save/resume of an in-progress round using local SharedPreferences.
- Settings for sound feedback, haptics and light/dark appearance.
- Original code-drawn visuals and an original vector app icon.
- No INTERNET permission, advertising SDK, analytics, account, or cloud service.
- Android 16 target (API 36), minimum API 23.

## Build an APK with GitHub Actions

1. Create a new **public or private** GitHub repository named `minoza-blocks`.
2. Upload the contents of this project ZIP to the repository root (not the ZIP file itself).
3. Open the repository's **Actions** tab and run **Build Android APK**, or push a commit to `main`.
4. When the workflow completes, open the run and download the `minoza-debug-apk` artifact.
5. The file is a debug APK for testing on Android. It is not the signed Play Store release.

The workflow installs Gradle 8.13 and Android SDK 36 in GitHub-hosted CI. This workspace does not contain an Android SDK/Gradle installation, so the APK has not been compiled or run on a physical phone here.

## Before a public Play Store release

This repository is a playable first prototype, not yet a Play Store-ready commercial release. Before publishing, complete device testing, accessibility and screen-size checks, finalize the brand name, create store screenshots/feature graphic, prepare a publicly hosted privacy policy, complete the Data safety and content-rating forms, and produce a signed release Android App Bundle (`.aab`). Review the current Google Play policies because requirements change.

For personal Play Console accounts created after 13 November 2023, Google currently requires a closed test with at least 12 opted-in testers continuously for 14 days before applying for production access. New app submissions currently need to target Android 16 / API 36 or higher.

## Package identity

- Working public title: `Minoza Blocks` (not legally cleared; verify app-name and trademark availability before launch).
- Application ID: `com.minoza.blocks`.
- Version: `0.1.0` (versionCode 1).

Changing the application ID after first publication creates a different Play Store app listing, so choose the final ID before publishing.
