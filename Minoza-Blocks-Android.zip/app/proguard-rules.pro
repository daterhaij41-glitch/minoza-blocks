# No custom keep rules are required for the first offline version.
